# C3-074A MeterStream fresh Gate case
Use the supplied case only after the Gate is assigned. Do not open protected reviews first.
