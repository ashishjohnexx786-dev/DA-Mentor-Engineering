"""Complete during the Gate. Do not claim a live stream unless you actually execute it."""

def build_contract():
    raise NotImplementedError("Define schema, event time, dedupe/window/checkpoint/sink contract")
