import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[json.loads(x) for x in (ROOT/'data/shipment_events.jsonl').read_text().splitlines() if x.strip()]
def test_rows(): assert len(rows)==20
def test_one_exact_duplicate(): assert len(rows)-len({r['event_id'] for r in rows})==1
def test_multiple_events_per_shipment(): assert len({r['shipment_id'] for r in rows})<len({r['event_id'] for r in rows})
def test_late_new_event_exists(): assert any(r['event_id']=='SE900' for r in rows)
