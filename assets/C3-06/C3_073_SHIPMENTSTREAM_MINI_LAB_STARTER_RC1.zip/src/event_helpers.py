"""Small API reminders for ShipmentStream; this is not a solved Mini-Lab pipeline."""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone


def parse_utc(value: str) -> datetime:
    """Parse the supplied ISO-8601 timestamp as UTC."""
    return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone.utc)


def load_jsonl(path: str | Path) -> list[dict]:
    """Load the small synthetic event fixture; learner must define validation/stream semantics."""
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
