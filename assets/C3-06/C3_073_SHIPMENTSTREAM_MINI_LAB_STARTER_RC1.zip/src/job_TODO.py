"""ShipmentStream Mini-Lab TODO - deliberately incomplete."""
# Build from the supplied parcel lifecycle events. Do NOT copy the practice order schema.
# Required design/build decisions:
# 1) explicit shipment-event schema and event_id identity
# 2) partition key / ordering scope (justify shipment_id or another choice)
# 3) exact-event duplicate handling without deduping legitimate lifecycle events
# 4) event-time window + lateness/watermark policy
# 5) checkpointed restart evidence and intentional new-query replay boundary
# 6) Kafka-source translation while keeping transformations DataFrame-based
# 7) Delta Bronze/Silver sink contract with replay/idempotency reasoning
# 8) lag/throughput/state/watermark/sink monitoring + recovery runbook


def build_shipmentstream_job(*args, **kwargs):
    raise NotImplementedError("Mini-Lab: implement independently after saving your design assumptions.")
