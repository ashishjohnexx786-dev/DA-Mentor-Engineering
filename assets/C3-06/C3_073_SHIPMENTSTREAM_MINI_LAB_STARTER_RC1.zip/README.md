# RC1 - ShipmentStream Mini-Lab
Fresh October parcel lifecycle events. Do not dedupe on shipment_id; one shipment legitimately has multiple events. Run source controls, then build your own solution.
