import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[json.loads(x) for x in (ROOT/'data/shipment_events.jsonl').read_text().splitlines() if x.strip()]
print('rows',len(rows)); print('unique_event_ids',len({r['event_id'] for r in rows})); print('shipments',len({r['shipment_id'] for r in rows}))
