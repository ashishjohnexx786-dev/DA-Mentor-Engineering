# C3-06 Streaming & Event-Driven Pipelines - Practice Project - RC1

Core executable simulator requires only Python + pytest. It teaches event identity, replay, duplicates, event time, simplified watermark reasoning and checkpoint state without pretending to be Kafka or Spark.

Live tool baselines: Apache Kafka 4.3.1; Spark Structured Streaming 4.2.0; Delta Lake 4.4.0; Debezium stable 3.6.2.Final. Use one heavy local tool at a time on the learning laptop.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
python scripts/run_stream_simulator.py --input data/inbox/events_batch_01.jsonl
python scripts/run_stream_simulator.py --input data/inbox/events_batch_02_late_duplicate_v2.jsonl
```

The simulator is deliberately documented as a teaching model, not an exact implementation of Kafka partitioning or Spark watermark internals. Live Kafka/Spark evidence is required only when those tools are actually run.
