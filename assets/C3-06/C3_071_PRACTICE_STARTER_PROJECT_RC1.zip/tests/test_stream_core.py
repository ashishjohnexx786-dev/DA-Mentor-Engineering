from pathlib import Path
from src.stream_core import *
ROOT=Path(__file__).resolve().parents[1]
b1=load_jsonl(ROOT/'data/inbox/events_batch_01.jsonl'); b2=load_jsonl(ROOT/'data/inbox/events_batch_02_late_duplicate_v2.jsonl')

def test_files_have_expected_rows(): assert len(b1)==16 and len(b2)==11

def test_all_base_events_valid():
    assert all(validate_event(e)[0] for e in b1+b2)

def test_stable_partition_range():
    assert all(0<=partition_for(e['order_id'],3)<3 for e in b1+b2)

def test_batch1_all_new():
    r=process_batch(b1,initial_state(),10); assert len(r['accepted'])==16 and not r['duplicates'] and not r['too_late']

def test_batch2_duplicate_and_late_classified():
    r1=process_batch(b1,initial_state(),10); r2=process_batch(b2,r1['state'],10)
    assert len(r2['duplicates'])==1
    assert any(e['event_id']=='E0006' for e in r2['duplicates'])
    assert any(e['event_id']=='E9001' for e in r2['too_late'])

def test_same_batch_replay_is_idempotent():
    r1=process_batch(b1,initial_state(),10); r2=process_batch(b1,r1['state'],10)
    assert len(r2['accepted'])==0 and len(r2['duplicates'])==16

def test_schema_v2_additive_event_is_valid():
    e=next(e for e in b2 if e['event_id']=='E9002'); assert e['schema_version']==2 and e['source_device']=='scanner-7' and validate_event(e)[0]

def test_window_keys_for_payments():
    r=process_batch(b1,initial_state(),10); assert all(isinstance(k,tuple) and len(k)==2 for k in r['windows'])
