import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'run_stream_simulator.py'


def run_cli(input_rel: str, state_path: Path):
    p = subprocess.run(
        [sys.executable, str(SCRIPT), '--input', input_rel, '--state', str(state_path)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert p.returncode == 0, p.stderr
    return json.loads(p.stdout)


def test_cli_batch_progress_and_replay(tmp_path):
    state = tmp_path / 'checkpoint.json'
    first = run_cli('data/inbox/events_batch_01.jsonl', state)
    second = run_cli('data/inbox/events_batch_02_late_duplicate_v2.jsonl', state)
    replay = run_cli('data/inbox/events_batch_01.jsonl', state)
    assert (first['accepted'], first['duplicates'], first['too_late']) == (16, 0, 0)
    assert (second['accepted'], second['duplicates'], second['too_late']) == (9, 1, 1)
    assert (replay['accepted'], replay['duplicates']) == (0, 16)
    assert second['state']['accepted_total'] == 25
