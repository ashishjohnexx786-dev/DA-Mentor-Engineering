# L03 Consumer Group Assignment

TODO: draw 1/2/3/5 consumers against 3 partitions and explain independent consumer groups.
