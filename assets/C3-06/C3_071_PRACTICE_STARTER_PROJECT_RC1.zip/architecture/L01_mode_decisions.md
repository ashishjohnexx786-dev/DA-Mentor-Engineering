# L01 Processing Mode Decisions

TODO: classify five workloads by boundedness, latency, replay requirement, state and operating cost.
