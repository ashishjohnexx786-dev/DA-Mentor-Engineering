# L02 Topic Design

TODO: topic name, partition count, replication assumptions, key, ordering scope, retention and justification.
