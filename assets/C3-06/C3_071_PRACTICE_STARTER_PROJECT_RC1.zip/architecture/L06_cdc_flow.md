# L06 CDC Flow

TODO: database log -> Debezium -> Kafka -> sink. Explain snapshot/change boundary, insert/update/delete envelopes and replay.
