# Complete during P09-P11 after installing PySpark 4.2.0.
from pathlib import Path
# from pyspark.sql import SparkSession, functions as F
# from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType
ROOT=Path(__file__).resolve().parents[1]
# TODO: explicit EVENT_SCHEMA
# TODO: SparkSession local[2], shuffle partitions 4 for tiny lab
# TODO: readStream.schema(EVENT_SCHEMA).json(str(ROOT/'data/stream_inbox'))
# TODO: parse event_time; withWatermark('event_time_ts','10 minutes')
# TODO: dedupe on event_id (consider dropDuplicatesWithinWatermark when appropriate)
# TODO: 5-minute event-time window for payment_received
# TODO: writeStream with stable checkpointLocation and trigger(availableNow=True)
# TODO: save query.lastProgress / recentProgress evidence only after actual run
