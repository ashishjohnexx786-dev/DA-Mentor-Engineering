# Structured Streaming Checkpoint Contract

TODO: stable path, query identity, configs/stateful schema that cannot be casually changed, backup/restore policy, fresh-query criteria.
