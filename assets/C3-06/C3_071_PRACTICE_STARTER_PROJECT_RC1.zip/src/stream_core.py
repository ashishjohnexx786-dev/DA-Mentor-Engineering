from __future__ import annotations
import json, hashlib
from pathlib import Path
from datetime import datetime, timezone, timedelta

def parse_ts(s: str) -> datetime:
    return datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)

def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]

def validate_event(e):
    req=['event_id','order_id','region','event_type','event_time','ingest_time','schema_version']
    missing=[k for k in req if k not in e or e[k] in (None,'')]
    if missing: return False, 'missing:'+','.join(missing)
    try: parse_ts(e['event_time']); parse_ts(e['ingest_time']); int(e['schema_version'])
    except Exception as ex: return False, 'type_or_time:'+type(ex).__name__
    return True, ''

def partition_for(key, n=3):
    # stable training hash; Kafka's actual partitioner implementation is not claimed.
    return int(hashlib.sha256(str(key).encode()).hexdigest()[:8],16) % n

def decorate_offsets(events,n=3):
    next_off={i:0 for i in range(n)}; out=[]
    for e in events:
        x=dict(e); p=partition_for(x['order_id'],n); x['_partition']=p; x['_offset']=next_off[p]; next_off[p]+=1; out.append(x)
    return out

def window_start(ts, minutes=5):
    t=parse_ts(ts); m=(t.minute//minutes)*minutes
    return t.replace(minute=m,second=0,microsecond=0).isoformat().replace('+00:00','Z')

def initial_state():
    return {'seen_event_ids':[], 'max_event_time':None, 'processed_files':[], 'accepted_total':0, 'duplicate_total':0, 'too_late_total':0, 'rejected_total':0}

def process_batch(events,state=None,lateness_minutes=10):
    state=dict(initial_state() if state is None else state)
    seen=set(state.get('seen_event_ids',[])); prior_max=parse_ts(state['max_event_time']) if state.get('max_event_time') else None
    prior_watermark=(prior_max-timedelta(minutes=lateness_minutes)) if prior_max else None
    accepted=[]; duplicates=[]; too_late=[]; rejected=[]
    max_t=prior_max
    for e in events:
        ok,reason=validate_event(e)
        if not ok: rejected.append((e,reason)); continue
        et=parse_ts(e['event_time'])
        if e['event_id'] in seen:
            duplicates.append(e); continue
        # simplified deterministic teaching simulator: classify events at/before PRIOR watermark as too-late.
        if prior_watermark is not None and et <= prior_watermark:
            too_late.append(e); seen.add(e['event_id']); continue
        accepted.append(e); seen.add(e['event_id']); max_t=et if max_t is None or et>max_t else max_t
    windows={}
    for e in accepted:
        if e['event_type']=='payment_received':
            k=(e['region'],window_start(e['event_time']))
            windows[k]=windows.get(k,0)+1
    state['seen_event_ids']=sorted(seen)
    state['max_event_time']=max_t.isoformat().replace('+00:00','Z') if max_t else None
    state['accepted_total']=state.get('accepted_total',0)+len(accepted)
    state['duplicate_total']=state.get('duplicate_total',0)+len(duplicates)
    state['too_late_total']=state.get('too_late_total',0)+len(too_late)
    state['rejected_total']=state.get('rejected_total',0)+len(rejected)
    return {'accepted':accepted,'duplicates':duplicates,'too_late':too_late,'rejected':rejected,'windows':windows,'prior_watermark':prior_watermark.isoformat().replace('+00:00','Z') if prior_watermark else None,'state':state}

def load_state(path):
    p=Path(path); return json.loads(p.read_text()) if p.exists() else initial_state()

def save_state(path,state):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix('.tmp'); tmp.write_text(json.dumps(state,indent=2,sort_keys=True)); tmp.replace(p)
