"""Practice streaming package marker."""
