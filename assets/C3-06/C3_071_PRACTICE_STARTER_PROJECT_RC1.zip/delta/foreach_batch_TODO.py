# Design-only until a Delta-enabled Spark runtime is actually installed.
# TODO P12: define an idempotent foreachBatch(batch_df, batch_id) for Silver upsert.
# Requirements: stable event/business key, deterministic dedupe, transactionally committed sink,
# checkpoint separate from other queries, and replay/backfill rules that do not corrupt live state.
