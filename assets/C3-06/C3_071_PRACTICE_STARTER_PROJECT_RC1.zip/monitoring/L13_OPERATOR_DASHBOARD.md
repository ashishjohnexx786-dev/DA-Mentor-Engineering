# L13 Operator Dashboard

TODO: source lag, input rate, processed rate, batch duration, state rows/bytes, watermark, sink failures; thresholds and actions.
