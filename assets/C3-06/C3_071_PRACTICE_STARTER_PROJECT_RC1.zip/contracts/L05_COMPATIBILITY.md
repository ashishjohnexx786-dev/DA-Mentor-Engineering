# L05 Compatibility Analysis

TODO: classify additive optional field, rename, removal, required-field add and type change for replayed v1/v2 events.
