# L12 Streaming Lakehouse Contract

TODO: Bronze/Silver grain, event identity, schema policy, checkpoint identity, dedupe/upsert, replay/backfill, retention and validation.
