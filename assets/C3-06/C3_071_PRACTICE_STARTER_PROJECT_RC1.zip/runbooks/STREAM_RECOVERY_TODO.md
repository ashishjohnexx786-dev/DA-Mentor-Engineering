# Stream Recovery Runbook

TODO: detect -> diagnose -> protect source retention -> recover checkpoint/sink -> replay if needed -> reconcile -> resume -> post-incident note.
