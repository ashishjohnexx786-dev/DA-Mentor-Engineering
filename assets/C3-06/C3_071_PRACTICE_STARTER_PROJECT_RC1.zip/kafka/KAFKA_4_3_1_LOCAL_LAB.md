# Kafka 4.3.1 Local KRaft Lab

Use current Apache Kafka Quickstart. Java 17+ required. Do not run Spark/Airflow/Kafka simultaneously unless the integration lesson explicitly needs it.

```bash
# after extracting kafka_2.13-4.3.1
KAFKA_CLUSTER_ID="$(bin/kafka-storage.sh random-uuid)"
bin/kafka-storage.sh format --standalone -t "$KAFKA_CLUSTER_ID" -c config/server.properties
bin/kafka-server-start.sh config/server.properties
# separate terminal
bin/kafka-topics.sh --create --topic c3-orders --partitions 3 --replication-factor 1 --bootstrap-server localhost:9092
bin/kafka-console-producer.sh --topic c3-orders --bootstrap-server localhost:9092 --property parse.key=true --property key.separator=:
bin/kafka-console-consumer.sh --topic c3-orders --from-beginning --bootstrap-server localhost:9092 --group c3-learning
bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group c3-learning
```

RF=1 is a laptop constraint, not production HA evidence.
