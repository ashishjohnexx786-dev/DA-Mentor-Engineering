# L09 Watermark Experiment

TODO: max event time, watermark, windows, late-but-accepted vs too-late behavior, before/after counts.
