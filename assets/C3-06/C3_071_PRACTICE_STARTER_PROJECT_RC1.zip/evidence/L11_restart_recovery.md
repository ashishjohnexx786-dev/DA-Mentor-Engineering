# L11 Restart & Recovery

TODO: same checkpoint rerun, new checkpoint replay, stateful config change risk, recovery evidence.
