# L04 Replay Contract

TODO: per-partition offsets, retention headroom, replay range, isolated/idempotent sink, acceptance checks.
