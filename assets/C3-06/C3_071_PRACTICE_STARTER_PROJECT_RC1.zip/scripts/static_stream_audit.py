from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
text='\n'.join(p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.py','.md','.json'})
checks={
 'kafka_4_3_1': '4.3.1' in text,
 'spark_4_2_0': '4.2.0' in text,
 'stable_checkpoint_instruction': 'checkpoint' in text.lower(),
 'event_id_dedupe': 'event_id' in text and 'dedupe' in text.lower(),
 'event_time_watermark': 'withWatermark' in text or 'watermark' in text.lower(),
 'no_unbounded_collect_instruction': 'collect()' not in text or 'unbounded' in text.lower(),
 'cdc_present': 'Debezium' in text,
 'delta_boundary': 'Delta' in text and 'idempotent' in text.lower(),
}
for k,v in checks.items(): print(k,'PASS' if v else 'FAIL')
raise SystemExit(0 if all(checks.values()) else 1)
