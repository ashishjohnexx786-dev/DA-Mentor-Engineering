from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from src.stream_core import load_jsonl, process_batch, initial_state
s=initial_state()
r1=process_batch(load_jsonl(ROOT/'data/inbox/events_batch_01.jsonl'),s,10)
r2=process_batch(load_jsonl(ROOT/'data/inbox/events_batch_02_late_duplicate_v2.jsonl'),r1['state'],10)
print('batch1',len(r1['accepted']),len(r1['duplicates']),len(r1['too_late']),len(r1['rejected']))
print('batch2',len(r2['accepted']),len(r2['duplicates']),len(r2['too_late']),len(r2['rejected']))
print('state',r2['state'])
