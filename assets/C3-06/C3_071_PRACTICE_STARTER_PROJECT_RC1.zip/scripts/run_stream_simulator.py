import argparse, json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from src.stream_core import load_jsonl, load_state, save_state, process_batch

p=argparse.ArgumentParser()
p.add_argument('--input',required=True)
p.add_argument('--state',default='work/checkpoint.json')
p.add_argument('--lateness-minutes',type=int,default=10)
a=p.parse_args()
input_path=Path(a.input); input_path=input_path if input_path.is_absolute() else ROOT/input_path
state_path=Path(a.state); state_path=state_path if state_path.is_absolute() else ROOT/state_path
state=load_state(state_path)
result=process_batch(load_jsonl(input_path),state,a.lateness_minutes)
windows={f'{start}|{end}': value for (start,end), value in result['windows'].items()}
summary={
    'accepted': len(result['accepted']),
    'duplicates': len(result['duplicates']),
    'too_late': len(result['too_late']),
    'rejected': len(result['rejected']),
    'windows': windows,
    'prior_watermark': result['prior_watermark'],
    'state': result['state'],
}
# Build a JSON-safe summary before mutating persisted state.
payload=json.dumps(summary,indent=2,default=str)
save_state(state_path,result['state'])
print(payload)
