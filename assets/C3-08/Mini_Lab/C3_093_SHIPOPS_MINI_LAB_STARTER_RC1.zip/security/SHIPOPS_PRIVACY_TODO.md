# ShipOps privacy/security TODO

Synthetic evidence only; no secrets; least privilege; retention.
