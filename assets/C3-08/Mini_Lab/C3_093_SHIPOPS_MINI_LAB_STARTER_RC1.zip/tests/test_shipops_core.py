import csv
from pathlib import Path
from src.shipops_core import *
ROOT=Path(__file__).resolve().parents[1]
def load(p):
 with open(p,newline='') as f:return list(csv.DictReader(f))
def test_shipops_controls():
 s=load(ROOT/'data/shipments_source.csv'); t=load(ROOT/'data/shipments_target.csv'); assert missing_weight(s)==['SH904']; assert missing_keys(s,t)==['SH904']
