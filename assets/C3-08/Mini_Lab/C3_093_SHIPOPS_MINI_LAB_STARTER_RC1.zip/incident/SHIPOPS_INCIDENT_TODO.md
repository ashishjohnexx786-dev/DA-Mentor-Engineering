# ShipOps incident TODO

Detect -> block unsafe publish -> reconcile -> root cause -> repair affected scope -> post-repair reconcile -> prevention.
