# ShipOps signals TODO

Structured logs, metrics, SLI/SLO, page/ticket alert and safe evidence.
