# ShipOps Incident Mini-Lab
Fresh C3-08 integrated incident. Local helper test only proves fixture invariants; learner must perform incident reasoning and repair evidence.
