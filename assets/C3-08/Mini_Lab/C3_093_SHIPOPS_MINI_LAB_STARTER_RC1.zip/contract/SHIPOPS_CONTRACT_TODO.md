# ShipOps contract TODO

Grain/key/required weight/severity/ownership/publish policy.
