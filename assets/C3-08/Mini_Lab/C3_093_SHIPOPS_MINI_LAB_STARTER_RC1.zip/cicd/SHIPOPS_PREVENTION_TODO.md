# ShipOps prevention TODO

Tests + CI/release gate preventing silent drop of required-weight row.
