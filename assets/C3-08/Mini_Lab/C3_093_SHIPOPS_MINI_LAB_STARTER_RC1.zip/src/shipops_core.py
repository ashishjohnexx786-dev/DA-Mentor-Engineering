def missing_keys(source,target,key='shipment_id'):
    return sorted({r[key] for r in source}-{r[key] for r in target})
def missing_weight(rows): return sorted(r['shipment_id'] for r in rows if not r.get('weight_kg'))
