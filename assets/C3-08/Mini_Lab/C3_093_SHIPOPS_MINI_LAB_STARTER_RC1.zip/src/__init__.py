# ShipOps helpers.
