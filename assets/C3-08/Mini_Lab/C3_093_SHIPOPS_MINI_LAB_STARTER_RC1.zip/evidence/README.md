Save learner-created logs/checks/reconciliation/timeline/runbook/test evidence here.
