from pathlib import Path
import ast,re,json
ROOT=Path(__file__).resolve().parents[1]
py=list(ROOT.rglob('*.py')); syntax=[]
for p in py:
    try: ast.parse(p.read_text())
    except Exception as e: syntax.append([str(p.relative_to(ROOT)),str(e)])
patterns=[r'AKIA[0-9A-Z]{16}',r'ghp_[A-Za-z0-9]{30,}',r'AccountKey=',r'password\s*=\s*["\'][^"\']+["\']']
hits=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.name!='static_project_audit.py' and p.suffix.lower() in {'.py','.md','.json','.yml','.yaml','.tf','.txt'}:
        text=p.read_text(errors='ignore')
        for pat in patterns:
            if re.search(pat,text,re.I): hits.append(str(p.relative_to(ROOT)))
print(json.dumps({'python_files':len(py),'syntax_errors':syntax,'secret_like_hits':sorted(set(hits))},indent=2))
assert not syntax and not hits
