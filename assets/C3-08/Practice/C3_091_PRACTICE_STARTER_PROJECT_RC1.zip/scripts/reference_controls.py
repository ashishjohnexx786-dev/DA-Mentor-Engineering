from pathlib import Path
import json,csv,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.reliability_core import *
s=load_csv(ROOT/'data/source_orders.csv'); t=load_csv(ROOT/'data/target_orders_corrupt.csv'); r=reconcile(s,t)
with open(ROOT/'slo/sli_history.csv',newline='') as f: hist=list(csv.DictReader(f))
print(json.dumps({'quality':quality_findings(s),'reconcile':r,'freshness_minutes':freshness_minutes(s,'2026-09-09T09:00:00Z'),'validated_publish_ratio':sli_ratio(hist,'validated_publish'),'on_time_ratio':sli_ratio(hist,'on_time')},indent=2))
