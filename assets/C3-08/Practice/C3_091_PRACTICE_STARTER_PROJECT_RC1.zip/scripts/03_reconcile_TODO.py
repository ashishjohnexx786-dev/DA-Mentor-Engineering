# TODO: use src.reliability_core.reconcile, explain every missing/extra/mismatch, then design changed-case validation.
raise NotImplementedError
