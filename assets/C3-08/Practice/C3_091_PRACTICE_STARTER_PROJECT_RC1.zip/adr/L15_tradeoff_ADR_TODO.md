# L15 ADR - Reliability / performance / cost

Context:
Options:
Correctness/security floor:
Latency/freshness impact:
Reliability/detection impact:
Compute/operator cost:
Decision:
Rejected alternatives:
Metrics and review trigger:
