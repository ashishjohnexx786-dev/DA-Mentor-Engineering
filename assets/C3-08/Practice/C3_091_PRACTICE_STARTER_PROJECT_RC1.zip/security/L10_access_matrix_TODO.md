# L10 Access matrix

TODO: actor | task | repo permission | workflow permission | environment | cloud identity | secret/OIDC boundary | allow test | deny test | rotation/revocation.
