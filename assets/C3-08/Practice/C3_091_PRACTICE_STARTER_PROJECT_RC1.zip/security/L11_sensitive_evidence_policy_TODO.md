# L11 Sensitive evidence policy

TODO: classification, minimize, encrypt in transit/at rest, access, mask/redact, retention, deletion, incident exception.
