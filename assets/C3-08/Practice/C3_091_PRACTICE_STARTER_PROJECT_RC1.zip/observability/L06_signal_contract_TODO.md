# L06 Signal contract

TODO: signal | fields | correlation | cardinality | sensitive-data rule | retention | owner | diagnostic use.
