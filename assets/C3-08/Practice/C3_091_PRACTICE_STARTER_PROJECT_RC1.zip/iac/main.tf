terraform { required_version = ">= 1.9.0" }

# Learning-only placeholder. No provider/resources are configured so this file cannot provision paid infrastructure.
variable "environment" { type = string default = "dev" }
output "environment" { value = var.environment }
