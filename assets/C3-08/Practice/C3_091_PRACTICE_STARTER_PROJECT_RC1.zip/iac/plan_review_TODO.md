# L14 Terraform plan/state/drift review

TODO: desired config, current state, proposed actions, destructive/replace flags, sensitive state boundary, locking/backend, approval, drift repair. Do not run paid cloud apply.
