# L13 Promotion and rollback

TODO: immutable artifact version, env config, approvals, smoke/reconcile, state/schema compatibility, rollback vs roll-forward decision, bounded repair.
