# L02 Severity policy

TODO: rule | consumer impact | severity block/warn/info | publish action | owner | escalation | fresh changed case.
