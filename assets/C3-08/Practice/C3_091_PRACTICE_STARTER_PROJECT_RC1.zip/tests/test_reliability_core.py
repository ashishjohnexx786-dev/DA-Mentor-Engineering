from pathlib import Path
import csv
from src.reliability_core import *
ROOT=Path(__file__).resolve().parents[1]
def data(): return load_csv(ROOT/'data/source_orders.csv'),load_csv(ROOT/'data/target_orders_corrupt.csv')
def test_quality_warning_only_on_source():
    s,_=data(); f=quality_findings(s); assert f==[{'rule':'customer_id_present','severity':'warn','key':'O504'}]
def test_reconcile_detects_two_defects():
    s,t=data(); r=reconcile(s,t); assert r['missing_keys']==['O506']; assert r['extra_keys']==[]; assert r['mismatched']==[{'key':'O503','source':330.0,'target':300.0}]
def test_reconcile_totals():
    s,t=data(); r=reconcile(s,t); assert r['source_total']==3770.0 and r['target_total']==3130.0
def test_freshness_control():
    s,_=data(); assert freshness_minutes(s,'2026-09-09T09:00:00Z')==150
def test_sli_ratios():
    with open(ROOT/'slo/sli_history.csv',newline='') as f: rows=list(csv.DictReader(f)); assert sli_ratio(rows,'validated_publish')==0.8 and sli_ratio(rows,'on_time')==0.8
def test_sanitize():
    x=sanitize_record({'customer_email':'asha@example.test','api_token':'abc','order_id':'O1'}); assert x['customer_email']=='a***@example.test' and x['api_token']=='[REDACTED]' and x['order_id']=='O1'
def test_offsetting_error_still_visible():
    s,t=data(); t=t+[{'order_id':'OX','customer_id':'CX','status':'Completed','amount':'610.0','updated_at':'2026-09-09T06:31:00Z'}]; r=reconcile(s,t); assert r['missing_keys']==['O506'] and r['extra_keys']==['OX']
def test_duplicate_blocks():
    s,_=data(); f=quality_findings(s+[dict(s[0])]); assert any(x['rule']=='unique_order_id' and x['severity']=='block' for x in f)
