# C3-08 production reliability practice project

Run `python scripts/reference_controls.py`, `python scripts/static_project_audit.py`, and `pytest -q`. The supplied helper layer exposes deterministic mechanics but does not complete the learner's contracts, alert policy, incident analysis, CI/CD, release or IaC decisions. Keep protected reviews closed until each attempt is saved.
