# C3-08 reliability helper primitives.
