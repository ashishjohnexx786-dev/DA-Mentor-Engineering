from __future__ import annotations
import csv, json, re
from datetime import datetime, timezone
from pathlib import Path

def load_csv(path):
    with open(path,newline='') as f: return list(csv.DictReader(f))

def quality_findings(rows):
    findings=[]; seen=set()
    for r in rows:
        k=r['order_id']
        if k in seen: findings.append({'rule':'unique_order_id','severity':'block','key':k})
        seen.add(k)
        try: amount=float(r['amount'])
        except Exception: amount=-1
        if amount < 0: findings.append({'rule':'amount_non_negative','severity':'block','key':k})
        if r['status'] not in {'Completed','Pending','Cancelled'}: findings.append({'rule':'status_domain','severity':'block','key':k})
        if not r.get('customer_id'): findings.append({'rule':'customer_id_present','severity':'warn','key':k})
    return findings

def reconcile(source,target,key='order_id',numeric='amount'):
    s={r[key]:r for r in source}; t={r[key]:r for r in target}
    missing=sorted(set(s)-set(t)); extra=sorted(set(t)-set(s)); mismatch=[]
    for k in sorted(set(s)&set(t)):
        if float(s[k][numeric]) != float(t[k][numeric]): mismatch.append({'key':k,'source':float(s[k][numeric]),'target':float(t[k][numeric])})
    return {'source_rows':len(source),'target_rows':len(target),'missing_keys':missing,'extra_keys':extra,'mismatched':mismatch,'source_total':sum(float(r[numeric]) for r in source),'target_total':sum(float(r[numeric]) for r in target)}

def freshness_minutes(rows,observation_time,ts='updated_at'):
    obs=datetime.fromisoformat(observation_time.replace('Z','+00:00')); latest=max(datetime.fromisoformat(r[ts].replace('Z','+00:00')) for r in rows)
    return int((obs-latest).total_seconds()/60)

def sli_ratio(rows,field):
    return sum(int(r[field]) for r in rows)/len(rows) if rows else 0.0

def sanitize_value(name,value):
    n=name.lower()
    if any(x in n for x in ['token','secret','password','key']): return '[REDACTED]'
    if 'email' in n and isinstance(value,str) and '@' in value:
        local,domain=value.split('@',1); return (local[:1]+'***@'+domain)
    return value

def sanitize_record(d): return {k:sanitize_value(k,v) for k,v in d.items()}
