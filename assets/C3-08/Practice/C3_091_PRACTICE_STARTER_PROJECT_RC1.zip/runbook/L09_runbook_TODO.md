# L09 Runbook

1 Purpose/owner
2 Preconditions
3 Commands/actions
4 Success evidence
5 Diagnostics
6 Safe rerun/recovery
7 Reconciliation
8 Escalation
9 Limitations
10 Changed credential-failure branch
