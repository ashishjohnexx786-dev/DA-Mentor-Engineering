# L08 Incident timeline

TODO: detected -> impact -> containment -> evidence -> root cause -> contributing factors -> repair -> reprocess -> post-repair reconcile -> prevention.
