# L12 CI/CD checklist

TODO: PR triggers, tests, data-contract check, least workflow permissions, protected production environment, OIDC/secret boundary, concurrency, post-deploy reconciliation, rollback/roll-forward.
