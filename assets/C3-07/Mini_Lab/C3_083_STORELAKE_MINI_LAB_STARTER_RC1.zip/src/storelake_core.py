def merge_latest(base,delta,key='order_id',ts='updated_at'):
    out={r[key]:dict(r) for r in base}
    for r in delta:
        if r[key] not in out or r[ts]>out[r[key]][ts]: out[r[key]]=dict(r)
    return list(out.values())
def unique(rows,key): return len(rows)==len({r[key] for r in rows})
