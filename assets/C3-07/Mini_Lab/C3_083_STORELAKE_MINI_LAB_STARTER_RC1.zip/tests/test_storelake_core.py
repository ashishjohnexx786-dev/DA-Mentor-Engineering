from src.storelake_core import merge_latest,unique
def test_merge():
 b=[{'order_id':'A','updated_at':'1'}]; d=[{'order_id':'A','updated_at':'2'},{'order_id':'B','updated_at':'2'}]; f=merge_latest(b,d); assert len(f)==2 and unique(f,'order_id')
