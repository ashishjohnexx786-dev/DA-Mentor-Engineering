# TODO: Store analyst and Finance analyst control-plane + OneLake/SQL data-plane access; include negative tests.
