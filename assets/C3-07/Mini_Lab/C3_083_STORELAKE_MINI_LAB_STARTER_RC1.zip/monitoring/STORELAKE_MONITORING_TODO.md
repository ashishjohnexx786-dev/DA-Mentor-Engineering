# TODO: pipeline/notebook/query/capacity signals and one injected failure recovery.
