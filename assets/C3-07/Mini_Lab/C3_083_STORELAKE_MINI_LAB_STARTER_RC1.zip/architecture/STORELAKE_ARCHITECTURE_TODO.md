# StoreLake architecture TODO

Workspace/item layout, Bronze/Silver, Copy/pipeline, notebook/Spark, Warehouse/SQL serving, Git/Dev-Test, security and capacity schedule.
