Save real Fabric run IDs/screenshots/definitions/query outputs/reconciliation/security tests here. Do not fabricate cloud evidence.
