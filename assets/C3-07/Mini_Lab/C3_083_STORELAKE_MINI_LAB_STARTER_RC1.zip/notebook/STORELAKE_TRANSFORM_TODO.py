# TODO: Fabric notebook with Bronze -> Silver, incremental MERGE and reconciliation.
raise NotImplementedError
