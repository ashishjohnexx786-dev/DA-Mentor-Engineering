# StoreLake Fabric Mini-Lab
Fresh StoreLake scenario. Local tests only validate helper semantics. Cloud completion requires real Fabric evidence.

RC1: Build independently. Local helper tests prove merge semantics only; they do not prove Fabric execution. Save real tenant evidence separately.
