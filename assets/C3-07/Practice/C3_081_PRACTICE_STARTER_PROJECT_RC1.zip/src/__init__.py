# C3-07 local validation helpers.
