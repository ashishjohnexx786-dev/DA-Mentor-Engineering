from __future__ import annotations
import csv, json
from pathlib import Path
from datetime import datetime, timezone

def load_csv(path):
    with open(path,newline='') as f: return list(csv.DictReader(f))

def latest_merge(base, delta, key='order_id', ts='updated_at'):
    out={r[key]:dict(r) for r in base}
    updates=inserts=0
    for r in sorted(delta,key=lambda x:x[ts]):
        k=r[key]
        if k in out:
            if r[ts] > out[k][ts]: out[k]=dict(r); updates+=1
        else: out[k]=dict(r); inserts+=1
    return list(out.values()), {'updates':updates,'inserts':inserts}

def unique(rows,key): return len(rows)==len({r[key] for r in rows})
def total_completed(rows): return round(sum(float(r['net_amount']) for r in rows if r['status']=='Completed'),2)
def max_watermark(rows): return max(r['updated_at'] for r in rows)
def load_jsonl(path): return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]
def bin5(ts):
    d=datetime.fromisoformat(ts.replace('Z','+00:00')).astimezone(timezone.utc); m=(d.minute//5)*5
    return d.replace(minute=m,second=0,microsecond=0).isoformat().replace('+00:00','Z')
def telemetry_summary(rows):
    out={}
    for r in rows:
        k=(r['site'],bin5(r['event_time'])); s=out.setdefault(k,{'events':0,'temperature_sum':0.0,'suspect':0}); s['events']+=1; s['temperature_sum']+=float(r['temperature']); s['suspect']+=int(r.get('status')=='suspect')
    return {k:{'events':v['events'],'avg_temp':round(v['temperature_sum']/v['events'],2),'suspect':v['suspect']} for k,v in out.items()}
def security_matrix_lint(rows):
    required={'principal','control_plane','data_plane','allowed','blocked_test'}
    return all(required.issubset(set(r)) and r.get('blocked_test') for r in rows)
