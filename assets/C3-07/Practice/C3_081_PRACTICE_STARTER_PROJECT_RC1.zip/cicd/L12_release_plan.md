# L12 Release Plan

TODO: feature branch -> review -> sync -> Dev validation -> deployment/Test -> remap environment/connection/Lakehouse references -> smoke/reconcile -> rollback. Mark Preview item lifecycles. Git tracks definitions/metadata, not OneLake table/file data.
