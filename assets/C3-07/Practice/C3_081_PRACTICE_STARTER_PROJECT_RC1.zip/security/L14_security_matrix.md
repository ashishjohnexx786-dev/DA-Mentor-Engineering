# L14 Security Matrix

TODO: principal, control-plane role/permission, OneLake role, tables/folders/schemas, RLS/CLS, SQL controls/masking, sensitivity/audit, allowed test, blocked test. OneLake roles are grants; inspect alternate permission paths and broad/default reader access.
