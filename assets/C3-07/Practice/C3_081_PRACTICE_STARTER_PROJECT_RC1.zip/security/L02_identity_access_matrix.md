# L02 Identity & Access

TODO columns: principal, job, workspace/item control plane, OneLake/SQL data plane, secret boundary, expected allow, expected deny, consumer test.
