# L13 Monitoring

TODO: workload, signal, threshold, owner, diagnostic path, action, post-action validation. Include pipeline, Spark, Warehouse, Eventhouse/Eventstream, capacity. Mark Eventstream workspace monitoring Preview.
