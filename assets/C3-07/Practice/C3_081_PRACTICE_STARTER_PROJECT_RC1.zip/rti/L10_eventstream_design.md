# L10 Eventstream Design

TODO: source -> Eventstream transforms/routing -> Eventhouse/KQL database -> query/dashboard/Activator if justified.
