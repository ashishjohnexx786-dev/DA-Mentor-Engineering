# L11 Incremental Contract

Stable key order_id; watermark updated_at. TODO: read predicate, merge, commit order, insert/update/reject reconciliation, rerun proof, late correction behavior.
