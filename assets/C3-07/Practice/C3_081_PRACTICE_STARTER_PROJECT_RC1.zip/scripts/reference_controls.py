import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.fabric_reference import *
b=load_csv(ROOT/'data/orders_initial.csv'); d=load_csv(ROOT/'data/orders_incremental.csv'); f,m=latest_merge(b,d)
print({'base_rows':len(b),'delta_rows':len(d),'final_rows':len(f),'unique':unique(f,'order_id'),'updates':m['updates'],'inserts':m['inserts'],'completed_total':total_completed(f),'watermark':max_watermark(f),'telemetry_bins':len(telemetry_summary(load_jsonl(ROOT/'data/telemetry.jsonl')))})
