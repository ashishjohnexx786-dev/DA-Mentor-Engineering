from pathlib import Path
import ast, json, re
ROOT=Path(__file__).resolve().parents[1]
py=list(ROOT.rglob('*.py')); bad=[]
for p in py:
    try: ast.parse(p.read_text())
    except Exception as e: bad.append((str(p.relative_to(ROOT)),str(e)))
secret_patterns=[r'AccountKey=',r'Bearer\s+[A-Za-z0-9_-]{20,}',r'password\s*=\s*["\'][^"\']+["\']']
leaks=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.py','.md','.sql','.kql','.json','.txt'} and p.name!='static_project_audit.py':
        t=p.read_text(errors='ignore')
        for pat in secret_patterns:
            if re.search(pat,t,re.I): leaks.append(str(p.relative_to(ROOT)))
print(json.dumps({'python_files':len(py),'syntax_errors':bad,'secret_like_hits':sorted(set(leaks))},indent=2))
assert not bad and not leaks
