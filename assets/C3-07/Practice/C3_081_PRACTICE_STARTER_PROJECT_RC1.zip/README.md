# C3-07 Fabric practice project

This package separates local deterministic validation from live Microsoft Fabric evidence. Run `python scripts/reference_controls.py`, `python scripts/static_project_audit.py`, and `pytest -q`. Live Fabric pipeline/notebook/Warehouse/Eventhouse/Git/OneLake-security/capacity evidence must be produced in an eligible Fabric environment; this package never fabricates it. Use only synthetic/public data.


RC1 rule: current Microsoft Learn docs control portal-sensitive behavior. Never commit secrets, tenant IDs that must remain private, or fabricated cloud evidence. Live Fabric claims require actual observed tenant evidence.
