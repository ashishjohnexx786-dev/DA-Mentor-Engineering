# L08 Promotion Contract

TODO: environment, default Lakehouse, connection IDs, schedule, parameter mapping, post-deploy run/reconciliation. Current SJD Git integration is preview and cross-workspace references need validation/remapping.
