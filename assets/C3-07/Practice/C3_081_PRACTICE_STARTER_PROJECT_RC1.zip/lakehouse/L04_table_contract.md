# L04 Lakehouse Contract

Bronze grain: source record. Silver grain: one current row per order_id. TODO schema, key, quarantine, reconciliation, rerun.
