# Fabric notebook transfer TODO
# Read Bronze with explicit schema; validate; transform; MERGE/write Silver; reconcile.
raise NotImplementedError("Implement in Fabric notebook or approved Spark runtime")
