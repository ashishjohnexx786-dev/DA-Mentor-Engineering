# L05 Tool Decision

TODO: Copy activity vs pipeline vs Dataflow Gen2 vs notebook/Spark vs current adjacent Copy Job. Note: all new Dataflow Gen2 items have CI/CD + Git support by default (2026).
