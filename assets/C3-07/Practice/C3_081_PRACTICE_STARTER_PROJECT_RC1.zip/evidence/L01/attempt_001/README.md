Save first-attempt evidence here. Do not overwrite it; changed retries go in sibling retry folders.
