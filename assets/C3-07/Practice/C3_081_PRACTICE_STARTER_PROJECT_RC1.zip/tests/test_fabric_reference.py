from pathlib import Path
from src.fabric_reference import *
ROOT=Path(__file__).resolve().parents[1]
def data(): return load_csv(ROOT/'data/orders_initial.csv'),load_csv(ROOT/'data/orders_incremental.csv')
def test_merge_controls():
    b,d=data(); f,m=latest_merge(b,d); assert len(f)==7 and m=={'updates':1,'inserts':1} and unique(f,'order_id')
def test_rerun_idempotent():
    b,d=data(); f,_=latest_merge(b,d); f2,_=latest_merge(f,d); assert len(f2)==7 and total_completed(f2)==total_completed(f)
def test_business_total():
    b,d=data(); f,_=latest_merge(b,d); assert total_completed(f)==8050.0
def test_watermark():
    b,d=data(); f,_=latest_merge(b,d); assert max_watermark(f)=='2026-08-05T08:05:00Z'
def test_telemetry():
    s=telemetry_summary(load_jsonl(ROOT/'data/telemetry.jsonl')); assert sum(v['events'] for v in s.values())==12 and sum(v['suspect'] for v in s.values())==1
