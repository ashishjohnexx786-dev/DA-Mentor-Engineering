# L15 Capacity + DP-700

TODO: workload schedule, concurrency, SLA, CU evidence, contention response. Map evidence to current DP-700 domains: Implement/manage 30-35%; Ingest/transform 30-35%; Monitor/optimize 30-35%.
