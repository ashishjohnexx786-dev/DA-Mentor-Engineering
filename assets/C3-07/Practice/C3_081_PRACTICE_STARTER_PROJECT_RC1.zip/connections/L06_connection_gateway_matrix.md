# L06 Connections

TODO: source, network location, auth identity, connection, gateway needed?, parameter, secret location, test.
