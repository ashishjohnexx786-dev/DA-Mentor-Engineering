# L01 Cloud Boundaries

TODO: storage / compute / control-plane / identity / network boundaries and changed private-source case.
