# L03 OneLake Choice

TODO: source -> copy / shortcut / mirroring / direct OneLake, with ownership, freshness, transformation, security, replay rationale.
