FleetFabric C3-07 fresh Gate C case. Do not open protected review until your attempt is saved. Use supplied synthetic data only.
