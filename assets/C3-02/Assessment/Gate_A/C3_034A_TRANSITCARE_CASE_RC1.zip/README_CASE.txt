C3-034A TransitCare. Learner-visible synthetic inputs only. Build transformation logic independently. No answer code included.
