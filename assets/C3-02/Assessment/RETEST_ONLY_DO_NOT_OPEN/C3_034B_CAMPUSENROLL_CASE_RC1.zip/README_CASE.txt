C3-034B CampusEnroll. Learner-visible synthetic inputs only. Build transformation logic independently. No answer code included.
