C3-034C HotelOps. Learner-visible synthetic inputs only. Build transformation logic independently. No answer code included.
