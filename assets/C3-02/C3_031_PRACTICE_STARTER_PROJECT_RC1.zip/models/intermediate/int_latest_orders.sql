-- TODO P02/P07: deterministic latest-row-per-order.
-- Required winner order: updated_at DESC, source_seq DESC.
select *
from {{ ref('stg_orders') }}
