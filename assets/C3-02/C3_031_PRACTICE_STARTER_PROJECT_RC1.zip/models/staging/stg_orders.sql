-- TODO P04: create a thin explicit staging contract. Do NOT deduplicate/business-classify here.
select *
from {{ source('raw', 'orders') }}
