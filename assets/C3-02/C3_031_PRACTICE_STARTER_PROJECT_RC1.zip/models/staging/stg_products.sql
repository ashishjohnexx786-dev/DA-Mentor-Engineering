-- TODO P04: explicit product source contract.
select *
from {{ source('raw', 'products') }}
