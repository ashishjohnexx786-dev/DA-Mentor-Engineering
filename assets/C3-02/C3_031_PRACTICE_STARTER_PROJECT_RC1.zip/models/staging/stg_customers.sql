-- TODO P04: replace SELECT * with explicit columns/types/names.
select *
from {{ source('raw', 'customers') }}
