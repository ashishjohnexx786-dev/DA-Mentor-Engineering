-- TODO P04: explicit columns and numeric casts; preserve order_id + line_no grain.
select *
from {{ source('raw', 'order_items') }}
