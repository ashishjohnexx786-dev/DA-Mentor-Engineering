-- TODO P11: one row per order_id + line_no; paid/current-order logic must be explicit.
-- Reconcile row count and gross amount before/after dimension joins.
select *
from {{ ref('stg_order_items') }}
