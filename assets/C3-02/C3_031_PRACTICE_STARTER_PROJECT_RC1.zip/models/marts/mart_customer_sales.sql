-- TODO P11/P14: one row per customer serving model derived from the fact.
select *
from {{ ref('dim_customers') }}
