-- TODO P11/P12: deterministic customer surrogate + explicit unknown/late-dimension policy.
select *
from {{ ref('stg_customers') }}
