-- TODO P08: implement a dbt snapshot for customer history.
-- Use customer_id as entity key and a justified timestamp/check strategy.
-- Keep this file syntactically incomplete only in business logic, not by inserting a worked solution.
{% snapshot customers_snapshot %}
{{ config(target_schema='snapshots', unique_key='customer_id', strategy='timestamp', updated_at='updated_at') }}

select * from {{ source('raw', 'customers') }}

{% endsnapshot %}
