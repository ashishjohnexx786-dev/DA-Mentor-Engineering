# C3-02 Transformation Lab - BEGIN HERE

This is an intentionally incomplete learner project. Do not look for a hidden solution.

1. Complete `C3_029_C3_02_TOOL_SETUP_FIRST_USE_RC1.pdf` before L03.
2. Use Python 3.13 in `.venv-c3-02`; do not reuse/mutate another course venv.
3. Copy `profiles.yml.example` to local `profiles.yml`; never commit credentials.
4. Run `python scripts/static_fixture_audit.py` before editing business logic.
5. Work lesson-by-lesson. TODO models are scaffolds, not answers.
6. Keep `warehouse.duckdb`, target/, logs/, cache, venv and real secrets out of Git.

Mastery requires independent changed tasks and validation, not simply making `dbt run` green.
