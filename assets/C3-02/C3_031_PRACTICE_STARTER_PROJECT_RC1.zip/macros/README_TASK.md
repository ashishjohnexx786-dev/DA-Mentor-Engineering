# P09 macro task
Create one small macro that removes safe repeated SQL without hiding a business model.
Inspect compiled SQL when dbt runtime is available and prove output parity with explicit SQL.
Do not create a macro simply because Jinja exists.
