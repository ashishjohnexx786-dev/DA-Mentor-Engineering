# C3-02 Transformation Engineering Practice Project

This is a deliberately incomplete dbt + DuckDB scaffold, not a solved project.

## Clean setup
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp profiles.yml.example profiles.yml
python scripts/setup_duckdb.py
pytest -q
dbt debug --profiles-dir .
dbt parse --profiles-dir .
dbt ls --profiles-dir .
```

If dbt/DuckDB cannot be installed or run on your machine, save the real error and use the lesson Help Ladder. Do not fabricate command output.

Complete only the task matching the lesson currently being studied. Keep C3-032 closed until the genuine attempt is saved.
