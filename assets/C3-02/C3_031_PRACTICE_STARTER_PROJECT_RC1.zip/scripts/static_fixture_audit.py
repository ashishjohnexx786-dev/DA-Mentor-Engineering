"""Pure-Python fixture audit: useful before dbt runtime, but NOT a substitute for dbt build/test evidence."""
from pathlib import Path
import csv

ROOT=Path(__file__).resolve().parents[1]/"raw_sources"

def rows(name):
    with (ROOT/name).open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

orders=rows("orders_base.csv")
items=rows("order_items.csv")
customers=rows("customers_v1.csv")

assert len(orders)==4
assert len(items)==6
assert len(customers)==3
assert len({(r["order_id"],r["line_no"]) for r in items})==len(items)
print("STATIC_FIXTURE_AUDIT_PASS")
print("orders_source_versions",len(orders))
print("order_items",len(items))
print("customers_v1",len(customers))
