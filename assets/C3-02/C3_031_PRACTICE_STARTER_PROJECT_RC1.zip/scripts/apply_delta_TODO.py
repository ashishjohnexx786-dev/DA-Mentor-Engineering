"""P07/P08 helper boundary. Implement deliberate source-v2/delta loading; do not solve model logic here."""
raise NotImplementedError("Design how raw source versions/deltas are loaded for the practice run.")
