"""Create raw schema/tables from synthetic CSVs. Requires duckdb from dbt-duckdb environment."""
from pathlib import Path
import duckdb

HERE=Path(__file__).resolve().parents[1]
raw=HERE/"raw_sources"
db=HERE/"warehouse.duckdb"
con=duckdb.connect(str(db))
con.execute("create schema if not exists raw")
loads = {
    "customers": raw/"customers_v1.csv",
    "orders": raw/"orders_base.csv",
    "order_items": raw/"order_items.csv",
    "products": raw/"products.csv",
}
for table,path in loads.items():
    con.execute(f"create or replace table raw.{table} as select * from read_csv_auto(?)", [str(path)])
for table in loads:
    print(table, con.execute(f"select count(*) from raw.{table}").fetchone()[0])
con.close()
print(db)
