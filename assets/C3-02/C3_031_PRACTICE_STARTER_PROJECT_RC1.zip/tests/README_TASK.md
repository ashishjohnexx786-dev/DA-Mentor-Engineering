# P06 test task
Add:
- grain/uniqueness protection for the true model key
- required not-null checks
- relationship/orphan checks
- one custom singular SQL invariant
Create one controlled failing input/test, save the failure evidence, then repair the model/data/test correctly.
Do not disable the failing test to obtain green output.
