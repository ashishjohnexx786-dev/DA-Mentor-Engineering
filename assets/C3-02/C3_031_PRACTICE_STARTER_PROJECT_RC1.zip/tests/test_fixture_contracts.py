from pathlib import Path
import csv

RAW=Path(__file__).resolve().parents[1]/"raw_sources"

def load(name):
    with (RAW/name).open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

def test_order_line_grain_is_unique_in_source():
    rows=load("order_items.csv")
    keys=[(r["order_id"],r["line_no"]) for r in rows]
    assert len(keys)==len(set(keys))

def test_product_source_is_unique():
    rows=load("products.csv")
    keys=[r["product_id"] for r in rows]
    assert len(keys)==len(set(keys))

def test_base_contains_tied_order_versions_for_practice():
    rows=[r for r in load("orders_base.csv") if r["order_id"]=="O002"]
    assert len(rows)==2
    assert len({r["updated_at"] for r in rows})==1
    assert len({r["source_seq"] for r in rows})==2

def test_delta_has_update_and_insert():
    rows=load("orders_delta.csv")
    assert {r["order_id"] for r in rows}=={"O002","O004"}

def test_late_dimension_fixture_exists():
    rows=load("late_order.csv")
    assert rows[0]["customer_id"]=="C999"
