Build current customer dimension, order-line fact, and at least one useful serving model with declared grains.
