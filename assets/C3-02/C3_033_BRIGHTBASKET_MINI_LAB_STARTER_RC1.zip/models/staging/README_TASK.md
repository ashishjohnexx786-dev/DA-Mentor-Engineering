Build thin explicit source staging models. Do not copy solved logic from Practice.
