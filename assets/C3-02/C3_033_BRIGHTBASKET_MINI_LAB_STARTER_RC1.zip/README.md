# BrightBasket Mini-Lab Starter
Limited-hint integrated assessment. This package contains source data and project structure only, not solved transformations.
