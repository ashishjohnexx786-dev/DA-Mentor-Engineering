Create customer history snapshot. Entity key is customer_id; updated_at supplies change order.
