Protect grain, required fields, relationships and one meaningful invariant. Save one controlled failure/repair.
