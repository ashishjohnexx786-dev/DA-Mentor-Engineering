from pathlib import Path
import duckdb
HERE=Path(__file__).resolve().parents[1]
raw=HERE/"raw_sources"
con=duckdb.connect(str(HERE/"brightbasket.duckdb"))
con.execute("create schema if not exists raw")
for table,file in [("customers","customers_v1.csv"),("orders","orders_base.csv"),("order_items","order_items.csv"),("products","products.csv")]:
    con.execute(f"create or replace table raw.{table} as select * from read_csv_auto(?)",[str(raw/file)])
    print(table,con.execute(f"select count(*) from raw.{table}").fetchone()[0])
con.close()
