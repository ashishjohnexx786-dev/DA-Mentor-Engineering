import argparse

def build_parser():
    p=argparse.ArgumentParser(description="TODO P10: row-count utility")
    p.add_argument("input")
    p.add_argument("--output", required=True)
    return p

def main(argv=None):
    args=build_parser().parse_args(argv)
    # TODO: call reusable core, write stable JSON, return documented status.
    raise NotImplementedError("P10 learner task")

if __name__ == "__main__":
    raise SystemExit(main())
