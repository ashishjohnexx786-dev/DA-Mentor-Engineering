def count_rows(rows):
    # TODO P10: define a small reusable core contract.
    raise NotImplementedError
