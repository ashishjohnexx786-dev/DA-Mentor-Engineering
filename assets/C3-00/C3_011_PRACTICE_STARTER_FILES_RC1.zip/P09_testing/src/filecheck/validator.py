def missing_required(columns, required):
    return set(required) - set(columns)
