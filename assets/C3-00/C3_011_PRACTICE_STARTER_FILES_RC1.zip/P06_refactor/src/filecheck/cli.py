def main(argv=None):
    # TODO P06: parse CLI, call core, translate known failures.
    raise NotImplementedError("P06 learner task")

if __name__ == "__main__":
    raise SystemExit(main())
