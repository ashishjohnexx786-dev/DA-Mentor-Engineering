def inspect_rows(rows):
    # TODO P06: move reusable validation/business logic here.
    raise NotImplementedError("P06 learner task")
