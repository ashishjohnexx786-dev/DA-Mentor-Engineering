import argparse, csv, json

parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("--output", default="summary.json")
args = parser.parse_args()

with open(args.input, newline="", encoding="utf-8") as f:
    rows=list(csv.DictReader(f))

# TODO: this file deliberately mixes CLI, IO, validation, logic and output.
required={"id","name"}
missing=required-set(rows[0].keys() if rows else [])
if missing:
    raise SystemExit(f"missing columns: {sorted(missing)}")

result={"row_count":len(rows)}
with open(args.output,"w",encoding="utf-8") as f:
    json.dump(result,f,indent=2,sort_keys=True)
print(result)
