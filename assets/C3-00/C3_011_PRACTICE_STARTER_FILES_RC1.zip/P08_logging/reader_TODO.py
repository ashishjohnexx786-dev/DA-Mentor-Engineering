import logging
logger = logging.getLogger(__name__)

def read_text(path):
    # TODO P08: add useful INFO/ERROR context and preserve exceptions.
    raise NotImplementedError
