import os

def resolve_output_dir(cli_value=None):
    # TODO P07: CLI value > C3_OUTPUT_DIR > ./out
    raise NotImplementedError
