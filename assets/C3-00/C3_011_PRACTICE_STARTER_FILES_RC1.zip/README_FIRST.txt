C3-00 RC1 starter files. Work on copies/your attempt folders. No solutions are included. Never place real secrets in these files.
