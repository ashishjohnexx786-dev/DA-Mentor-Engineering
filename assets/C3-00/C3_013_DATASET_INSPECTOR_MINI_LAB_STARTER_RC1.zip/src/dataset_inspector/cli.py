import argparse

def build_parser():
    p=argparse.ArgumentParser(description="Dataset Inspector")
    p.add_argument("input")
    p.add_argument("--output", required=True)
    p.add_argument("--log-level")
    return p

def main(argv=None):
    args=build_parser().parse_args(argv)
    # TODO: CLI -> core -> validated output; stable exit codes.
    raise NotImplementedError("Mini-Lab learner task")

if __name__ == "__main__":
    raise SystemExit(main())
