def inspect_csv(path, required_columns=None):
    # TODO: return deterministic profile fields defined by C3-013.
    raise NotImplementedError("Mini-Lab learner task")
