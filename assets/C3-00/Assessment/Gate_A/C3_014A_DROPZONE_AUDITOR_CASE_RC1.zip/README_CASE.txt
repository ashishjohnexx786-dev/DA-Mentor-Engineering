Case A. Build a small auditor/profile utility. Required business check: order_id unique; customer_id references known customer where present; Completed amount control. Introduce no real secrets.
