Protected fresh retest C. Do not open unless assigned. Build a reproducible release snapshot with config precedence reasoning and safe rerun behavior.
