Protected fresh retest B. Do not open unless assigned. Validate an evidence bundle and publish deterministic summary only after controls pass.
