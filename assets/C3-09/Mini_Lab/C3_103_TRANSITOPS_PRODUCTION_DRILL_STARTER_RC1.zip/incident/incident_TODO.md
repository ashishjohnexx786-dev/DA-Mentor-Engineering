# Incident TODO
Inject missing/invalid delivered duration in a copy, contain, repair, reprocess, reconcile, prevent.
