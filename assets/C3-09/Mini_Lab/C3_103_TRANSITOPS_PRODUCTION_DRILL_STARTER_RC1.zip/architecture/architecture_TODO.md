# Architecture TODO
Batch -> current-state -> route metric; incremental correction; Spark scale-transfer; optional streaming decision.
