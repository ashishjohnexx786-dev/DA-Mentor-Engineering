from pathlib import Path
from src.transit_helpers import *
ROOT=Path(__file__).resolve().parents[1]
def test_fixture_unique(): assert key_unique(read(ROOT/'data/shipments.csv'))
def test_reference_avg(): assert delivered_avg(read(ROOT/'data/shipments.csv'))==85.8
def test_no_false_block_for_intransit_missing_duration(): assert blocking(read(ROOT/'data/shipments.csv'))==[]
def test_correction_value():
    r=read(ROOT/'data/shipments_correction.csv'); assert r==[{'shipment_id':'T903','route':'R2','status':'Delivered','delivery_minutes':'81','updated_at':'2026-09-09T06:00:00Z'}]
