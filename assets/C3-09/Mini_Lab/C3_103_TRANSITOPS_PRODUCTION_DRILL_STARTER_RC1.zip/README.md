# TransitOps Production Drill

Integrated limited-hint capstone drill. Use the supplied domain-specific fixture. Do not copy RetailPulse core into this project.


## Reliable local verification
From the project root, run `python -m pytest -q`. Save the output as evidence.
