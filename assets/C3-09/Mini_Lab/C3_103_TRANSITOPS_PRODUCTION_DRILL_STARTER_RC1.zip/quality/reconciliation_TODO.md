# Quality/reconciliation TODO
Prove correction T903 once, route metrics, one injected defect, post-recovery trust.
