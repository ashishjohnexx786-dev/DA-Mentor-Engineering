# Security TODO
Least privilege + synthetic/sanitized evidence.
