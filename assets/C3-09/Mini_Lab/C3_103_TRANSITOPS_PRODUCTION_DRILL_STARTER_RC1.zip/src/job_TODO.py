# TODO: build batch/current-state/route metric, incremental correction, failure injection, recovery and reconciliation.
raise NotImplementedError
