import csv

def read(path):
    with open(path,newline='') as f:return list(csv.DictReader(f))
def key_unique(rows): return len({r['shipment_id'] for r in rows})==len(rows)
def delivered_avg(rows):
    vals=[float(r['delivery_minutes']) for r in rows if r['status']=='Delivered' and r['delivery_minutes']!='']; return round(sum(vals)/len(vals),2)
def blocking(rows): return [r['shipment_id'] for r in rows if r['status']=='Delivered' and r['delivery_minutes']=='']
