# Contract TODO
Define shipment grain/key, status/delivery rules, correction semantics and severity.
