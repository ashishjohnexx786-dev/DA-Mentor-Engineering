# L11 Security/governance

TODO: actor | repo/workflow | workspace/item | OneLake/data plane | allow | deny | identity/OIDC/secret boundary | evidence sanitization | rotation/revocation.
