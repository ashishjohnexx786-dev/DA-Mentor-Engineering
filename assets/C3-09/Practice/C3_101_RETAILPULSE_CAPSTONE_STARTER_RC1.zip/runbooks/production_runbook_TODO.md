# RetailPulse production runbook

Purpose/owner:
Preconditions:
Batch/incremental run:
Success evidence:
Quality/reconciliation:
Diagnostics:
Safe retry/partial rerun/backfill:
Incident containment/recovery:
Security/escalation:
Known live-platform limits:
