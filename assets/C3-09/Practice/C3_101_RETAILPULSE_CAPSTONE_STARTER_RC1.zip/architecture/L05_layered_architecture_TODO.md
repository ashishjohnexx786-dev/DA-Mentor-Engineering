# L05 Layered architecture

TODO: Bronze contract | Silver contract | serving/Gold contract | Lakehouse/Warehouse boundary | Delta/table-format choice | replay/history | alternate consumer.
