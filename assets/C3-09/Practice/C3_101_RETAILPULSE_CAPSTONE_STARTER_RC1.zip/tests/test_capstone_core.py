from pathlib import Path
from src.capstone_core import *
ROOT=Path(__file__).resolve().parents[1]
def data(): return read_csv(ROOT/'data/base/orders_2026-09-02.csv'),read_csv(ROOT/'data/incremental/orders_2026-09-03.csv')
def test_source_quality_clean():
    b,i=data(); assert validate_orders(b)==[] and validate_orders(i)==[]
def test_merge_current_count_and_replay():
    b,i=data(); c=merge_current(b,i); assert len(c)==7; assert merge_current(c,i)==c
def test_correction_and_inserts_once():
    b,i=data(); c=merge_current(b,i); m={r['order_id']:r for r in c}; assert m['O102']['amount']=='1050.00'; assert list(x['order_id'] for x in c).count('O106')==1; assert list(x['order_id'] for x in c).count('O107')==1
def test_completed_revenue():
    b,i=data(); c=merge_current(b,i); assert sum(float(r['amount']) for r in c if r['status']=='Completed')==6910.0
def test_daily_sales():
    b,i=data(); d=daily_completed(merge_current(b,i)); assert d==[{'order_date':'2026-09-01','completed_orders':2,'completed_revenue':2300.0},{'order_date':'2026-09-02','completed_orders':1,'completed_revenue':1620.0},{'order_date':'2026-09-03','completed_orders':2,'completed_revenue':2990.0}]
def test_reconcile_clean():
    b,i=data(); c=merge_current(b,i); r=reconcile_current(b,i,c); assert r['missing_keys']==[] and r['extra_keys']==[] and r['mismatches']==[] and r['expected_completed_revenue']==6910.0
def test_injected_defect_detected():
    b,i=data(); c=merge_current(b,i); bad=inject_amount_defect(c); r=reconcile_current(b,i,bad); assert any(x['key']=='O104' and x['field']=='amount' for x in r['mismatches']); assert r['actual_completed_revenue']==6810.0
def test_duplicate_in_extract_blocks():
    b,_=data(); assert any(x['rule']=='unique_order_id_in_extract' for x in validate_orders(b+[dict(b[0])]))
def test_run_local(tmp_path):
    s=run_local(ROOT,tmp_path,True,'t1'); assert s=={'run_id':'t1','status':'success','current_rows':7,'completed_revenue':6910.0,'reconciled':True}; assert (tmp_path/'evidence/reconciliation.json').exists()
