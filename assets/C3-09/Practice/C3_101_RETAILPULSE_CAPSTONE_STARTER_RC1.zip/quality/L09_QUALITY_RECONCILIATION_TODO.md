# L09 quality/reconciliation

TODO: blocking checks, source/change/current/serving counts, key sets, record mismatches, completed revenue, backfill/recovery controls, offsetting-error test.
