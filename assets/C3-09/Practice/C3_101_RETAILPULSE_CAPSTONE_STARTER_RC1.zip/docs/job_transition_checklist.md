# Engineering transition checklist

- GitHub repo is reproducible and sanitized.
- Resume bullets state what was built/tested, not fake production usage.
- Can explain one quality failure, one recovery, one trade-off, one scale change.
- Can write SQL/Python independently and discuss Airflow/Spark/Fabric boundaries.
- C3-104 phase Gate passed before later C3-113 Final Production Gate attempt.
