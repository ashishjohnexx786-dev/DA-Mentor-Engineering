# L14 Handoff exercise

TODO: fresh-reviewer reproduction gaps, missing prerequisites, corrected instructions, sanitized evidence list.
