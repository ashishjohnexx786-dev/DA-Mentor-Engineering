# Portfolio evidence index

TODO: artifact | claim | command/run | validation | sanitized evidence | limitation | interview story. Never claim live production/cloud behavior without evidence.
