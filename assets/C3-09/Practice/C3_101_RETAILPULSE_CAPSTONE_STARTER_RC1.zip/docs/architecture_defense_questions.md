# Architecture defense questions

1 Why batch-first? 2 What is the row grain at each layer? 3 What makes incremental replay safe? 4 How do you detect silent corruption? 5 What can retry safely? 6 How do backfills avoid collateral changes? 7 Why is Spark included? 8 What would justify Kafka/streaming? 9 How do CI/CD and post-deploy reconciliation work? 10 What happens when a secret is exposed? 11 What changes at 10x/100x? 12 Which claims remain unproven without live Airflow/Spark/Fabric/GitHub execution?
