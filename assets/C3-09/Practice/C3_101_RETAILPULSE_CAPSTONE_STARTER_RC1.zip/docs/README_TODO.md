# RetailPulse portfolio README

Business problem | architecture | source contracts | how to reproduce | tests | quality/reconciliation | observability | security | CI/CD | incident/recovery | live-platform evidence | trade-offs | limitations.
