# L06 Transformation/dbt

TODO: define model grains, joins, completed-revenue rule, tests, independent validation, changed-rule regression. Current dbt Core reference: 1.11.11.
