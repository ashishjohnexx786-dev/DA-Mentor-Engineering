# RetailPulse capstone starter - INTERNAL QA

This starter provides deterministic local reference mechanics plus intentionally incomplete engineering artifacts. Run `python scripts/reference_controls.py`, `python scripts/run_local_reference.py --work work/reference_run`, `python scripts/incident_drill_reference.py`, `python scripts/static_project_audit.py`, and `pytest -q`. Do not mistake local reference execution for live Airflow/Spark/Fabric/GitHub deployment evidence.


## Reliable local verification
From the project root, run `python -m pytest -q`. Save the output as evidence.
