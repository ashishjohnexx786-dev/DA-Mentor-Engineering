# L10 Observability/SLO

TODO: run_id/correlation fields, validated-publish SLI, freshness SLI, SLO window/objective, page alert, ticket alert, owner, runbook, cardinality/privacy rule.
