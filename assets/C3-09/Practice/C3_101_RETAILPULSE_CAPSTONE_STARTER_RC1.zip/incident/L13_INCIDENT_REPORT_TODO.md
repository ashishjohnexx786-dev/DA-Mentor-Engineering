# L13 Incident report

Detected:
Impact:
Containment:
Evidence:
Root cause:
Contributing factors:
Repair scope:
Reprocess/backfill:
Post-recovery reconciliation:
Preventive tests/CI/runbook update:
Residual risk:
