# L08 scale-transfer note

TODO: why Spark exists here; partition/shuffle risks at 10x/100x; parity invariant; local-small-data cost caveat.
