# TODO: implement stable-key incremental update/insert logic, then prove replay idempotence and late-correction boundary.
raise NotImplementedError
