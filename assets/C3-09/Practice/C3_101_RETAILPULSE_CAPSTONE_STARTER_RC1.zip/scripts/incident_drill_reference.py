from pathlib import Path
import json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.capstone_core import *
base=read_csv(ROOT/'data/base/orders_2026-09-02.csv'); inc=read_csv(ROOT/'data/incremental/orders_2026-09-03.csv'); current=merge_current(base,inc)
corrupt=inject_amount_defect(current,'O104',-100.0); before=reconcile_current(base,inc,corrupt); after=reconcile_current(base,inc,current)
print(json.dumps({'injected_key':'O104','pre_repair':before,'post_repair':after},indent=2))
