from pathlib import Path
import json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.capstone_core import *
base=read_csv(ROOT/'data/base/orders_2026-09-02.csv'); inc=read_csv(ROOT/'data/incremental/orders_2026-09-03.csv')
current=merge_current(base,inc); rec=reconcile_current(base,inc,current); daily=daily_completed(current)
print(json.dumps({'base_rows':len(base),'incremental_rows':len(inc),'current_rows':len(current),'order_O102':next(r for r in current if r['order_id']=='O102'),'completed_revenue':rec['actual_completed_revenue'],'daily':daily,'reconcile':rec},indent=2))
