from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.capstone_core import run_local
p=argparse.ArgumentParser(); p.add_argument('--work',default=str(ROOT/'work/reference_run')); p.add_argument('--base-only',action='store_true'); p.add_argument('--run-id',default='local-reference')
a=p.parse_args(); print(json.dumps(run_local(ROOT,a.work,not a.base_only,a.run_id),indent=2))
