# TODO: implement your batch milestone using source-preserving landing metadata and safe rerun behavior. Compare against reference controls without copying final logic.
raise NotImplementedError
