from pathlib import Path
import csv,json,hashlib,shutil
from datetime import datetime, timezone

def read_csv(path):
    with open(path,newline='') as f: return list(csv.DictReader(f))

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    return h.hexdigest()

def validate_orders(rows):
    findings=[]; seen=set(); required=['order_id','customer_id','order_date','status','amount','updated_at']; domain={'Completed','Pending','Cancelled'}
    for i,r in enumerate(rows,2):
        for k in required:
            if not str(r.get(k,'')).strip(): findings.append({'rule':'required','severity':'block','row':i,'field':k})
        oid=r.get('order_id')
        if oid in seen: findings.append({'rule':'unique_order_id_in_extract','severity':'block','row':i,'key':oid})
        seen.add(oid)
        try:
            if float(r.get('amount','0')) < 0: findings.append({'rule':'nonnegative_amount','severity':'block','row':i,'key':oid})
        except Exception: findings.append({'rule':'numeric_amount','severity':'block','row':i,'key':oid})
        if r.get('status') not in domain: findings.append({'rule':'status_domain','severity':'block','row':i,'key':oid})
    return findings

def merge_current(base,changes):
    out={r['order_id']:dict(r) for r in base}
    for r in changes:
        k=r['order_id']; old=out.get(k)
        if old is None or (r['updated_at'], r['order_id']) >= (old['updated_at'], old['order_id']): out[k]=dict(r)
    return [out[k] for k in sorted(out)]

def daily_completed(rows):
    d={}
    for r in rows:
        if r['status']!='Completed': continue
        x=d.setdefault(r['order_date'],{'order_date':r['order_date'],'completed_orders':0,'completed_revenue':0.0})
        x['completed_orders']+=1; x['completed_revenue']+=float(r['amount'])
    return [dict(v,completed_revenue=round(v['completed_revenue'],2)) for _,v in sorted(d.items())]

def reconcile_current(base,changes,current):
    exp=merge_current(base,changes); em={r['order_id']:r for r in exp}; cm={r['order_id']:r for r in current}
    missing=sorted(set(em)-set(cm)); extra=sorted(set(cm)-set(em)); mismatch=[]
    for k in sorted(set(em)&set(cm)):
        for field in ['customer_id','order_date','status','amount','updated_at']:
            if str(em[k][field])!=str(cm[k][field]): mismatch.append({'key':k,'field':field,'expected':em[k][field],'actual':cm[k][field]})
    return {'expected_rows':len(exp),'actual_rows':len(current),'missing_keys':missing,'extra_keys':extra,'mismatches':mismatch,
            'expected_completed_revenue':round(sum(float(r['amount']) for r in exp if r['status']=='Completed'),2),
            'actual_completed_revenue':round(sum(float(r['amount']) for r in current if r['status']=='Completed'),2)}

def run_local(root,work,apply_incremental=True,run_id='local-001'):
    root=Path(root); work=Path(work); work.mkdir(parents=True,exist_ok=True)
    base_path=root/'data/base/orders_2026-09-02.csv'; inc_path=root/'data/incremental/orders_2026-09-03.csv'
    base=read_csv(base_path); inc=read_csv(inc_path) if apply_incremental else []
    findings=validate_orders(base)+validate_orders(inc)
    blocking=[x for x in findings if x['severity']=='block']
    if blocking: raise ValueError(f'blocking quality findings: {blocking}')
    landing=work/'landing'; bronze=work/'bronze'; silver=work/'silver'; gold=work/'gold'; evidence=work/'evidence'
    for p in [landing,bronze,silver,gold,evidence]: p.mkdir(parents=True,exist_ok=True)
    shutil.copy2(base_path,landing/base_path.name)
    if apply_incremental: shutil.copy2(inc_path,landing/inc_path.name)
    metadata={'run_id':run_id,'base_sha256':sha256(base_path),'incremental_sha256':sha256(inc_path) if apply_incremental else None,'base_rows':len(base),'incremental_rows':len(inc),'blocking_findings':0}
    (bronze/'ingestion_metadata.json').write_text(json.dumps(metadata,indent=2))
    current=merge_current(base,inc)
    with open(silver/'orders_current.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(current[0])); w.writeheader(); w.writerows(current)
    daily=daily_completed(current)
    with open(gold/'daily_completed_sales.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(daily[0])); w.writeheader(); w.writerows(daily)
    rec=reconcile_current(base,inc,current); (evidence/'reconciliation.json').write_text(json.dumps(rec,indent=2))
    summary={'run_id':run_id,'status':'success','current_rows':len(current),'completed_revenue':rec['actual_completed_revenue'],'reconciled':not(rec['missing_keys'] or rec['extra_keys'] or rec['mismatches'])}
    (evidence/'run_summary.json').write_text(json.dumps(summary,indent=2))
    with open(evidence/'events.jsonl','w') as f:
        for event in [{'event':'ingest_complete','run_id':run_id,'rows':len(base)+len(inc)},{'event':'publish_complete','run_id':run_id,'rows':len(current)},{'event':'reconcile_complete','run_id':run_id,'ok':summary['reconciled']}]: f.write(json.dumps(event)+'\n')
    return summary

def inject_amount_defect(current_rows,key='O104',delta=-100.0):
    out=[dict(r) for r in current_rows]
    for r in out:
        if r['order_id']==key: r['amount']=f"{float(r['amount'])+delta:.2f}"
    return out
