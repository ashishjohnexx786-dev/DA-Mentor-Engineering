# L12 CI/CD/release

TODO: PR checks, clean install, pytest/reference/static audit, protected environment, minimal permissions, OIDC where supported, concurrency, release checklist, post-deploy reconcile, rollback/roll-forward.
