# L07 backfill/recovery

TODO: interval identity, retryable/nonretryable failures, partial rerun, historical backfill command/design, unrelated-partition invariant.
