# TODO: Build CourierSpark independently using PySpark 4.2.0.
# Requirements: explicit schemas; clean + rejected; route uniqueness; join; route metrics; window rank;
# formatted plan; key-frequency/skew evidence; Parquet output; at least two tests; repeatable CLI.
