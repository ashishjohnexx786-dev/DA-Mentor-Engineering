import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ships=list(csv.DictReader(open(ROOT/'data/shipments.csv'))); routes=list(csv.DictReader(open(ROOT/'data/routes.csv')))
assert len(ships)==42; assert len({r['shipment_id'] for r in ships})==42
assert len(routes)==4 and len({r['route_id'] for r in routes})==4
assert sum(1 for r in ships if not r['delivery_minutes'])==1
assert sum(1 for r in ships if r['route_id']=='R1')==25
print('CourierSpark reference controls PASS')
