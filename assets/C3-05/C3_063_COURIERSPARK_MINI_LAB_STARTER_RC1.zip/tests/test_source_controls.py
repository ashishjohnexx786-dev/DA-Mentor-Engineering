import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_fixture():
    s=list(csv.DictReader(open(ROOT/'data/shipments.csv'))); r=list(csv.DictReader(open(ROOT/'data/routes.csv')))
    assert len(s)==42 and len({x['shipment_id'] for x in s})==42
    assert len(r)==4 and len({x['route_id'] for x in r})==4
    assert sum(1 for x in s if x['route_id']=='R1')==25
    assert sum(1 for x in s if not x['delivery_minutes'])==1
