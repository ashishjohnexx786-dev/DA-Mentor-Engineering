Status: BEGINNER-FIRST RC1 learner starter scaffold. Intentionally incomplete.

# CourierSpark Mini-Lab
Fresh integrated Spark problem. Use local[2]. Complete the TODO Spark job; do not copy practice transforms.


Runtime lane: Spark/PySpark 4.2.0; Python 3.10+; Java 17+. Save literal Spark evidence only after it actually runs.
