# Runbook
Detect:
Diagnose:
Recover:
Validate:
Rollback/cleanup:
