# Execution map
Driver -> lazy plan -> action -> job -> stage/tasks -> Exchange/shuffle -> next stage
