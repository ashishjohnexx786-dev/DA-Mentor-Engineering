from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
text="\n".join(x.read_text(errors="ignore") for x in ROOT.rglob("*.py") if x.name!="static_spark_audit.py")
checks={
 "local_2": "local[2]" in text,
 "shuffle_4": "spark.sql.shuffle.partitions" in text and "'4'" in text,
 "aqe_true": "spark.sql.adaptive.enabled" in text and "'true'" in text,
 "explicit_schema": "StructType" in text and "ORDER_RAW_SCHEMA" in text,
 "no_unbounded_collect_in_active_code": not any(re.search(r"\b(?:collect|toPandas)\s*\(", line) for line in text.splitlines() if not line.lstrip().startswith("#")),
 "formatted_explain_instruction": "formatted" in text and "explain" in text,
}
for k,v in checks.items(): print(k, "PASS" if v else "FAIL")
raise SystemExit(0 if all(checks.values()) else 1)
