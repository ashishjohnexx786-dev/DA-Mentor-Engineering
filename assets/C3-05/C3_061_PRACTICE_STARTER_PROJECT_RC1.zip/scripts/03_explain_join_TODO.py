from src.spark_session import build_spark
# TODO P10/P11: build your validated join/aggregation and call df.explain('formatted').
spark=build_spark('c3_05_explain')
try:
    pass
finally:
    spark.stop()
