import sys, subprocess
print('python', sys.version.split()[0])
try:
    import pyspark
    print('pyspark', pyspark.__version__)
except Exception as e:
    print('pyspark missing:', e)
print('Run java -version separately and save evidence. Required course baseline: Java 17+.')
