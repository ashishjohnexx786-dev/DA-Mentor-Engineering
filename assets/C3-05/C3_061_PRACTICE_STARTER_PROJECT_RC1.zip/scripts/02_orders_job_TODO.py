import argparse
from pathlib import Path
from src.spark_session import build_spark
# TODO P16: import your completed transforms and implement parameterized read -> validate -> join -> metrics -> Parquet publish.

def main():
    p=argparse.ArgumentParser(); p.add_argument('--orders',required=True); p.add_argument('--products',required=True); p.add_argument('--output',required=True); args=p.parse_args()
    spark=build_spark('c3_05_orders_job')
    try:
        raise NotImplementedError('Complete during P16; do not hardcode local absolute paths')
    finally:
        spark.stop()
if __name__=='__main__': main()
