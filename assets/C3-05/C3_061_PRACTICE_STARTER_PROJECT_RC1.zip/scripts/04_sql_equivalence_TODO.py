# TODO P09: DataFrame aggregation -> temp view -> spark.sql equivalent -> parity check.
