from pathlib import Path
from src.spark_session import build_spark
from src.schemas import ORDER_RAW_SCHEMA
ROOT=Path(__file__).resolve().parents[1]
spark=build_spark('c3_05_read')
# TODO P03: read data/practice/orders.csv with header + ORDER_RAW_SCHEMA; save schema/count/partition evidence.
spark.stop()
