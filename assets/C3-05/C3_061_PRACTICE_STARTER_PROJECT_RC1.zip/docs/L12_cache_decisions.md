# Cache decisions
Candidate | reused? | expensive? | size risk? | decision
