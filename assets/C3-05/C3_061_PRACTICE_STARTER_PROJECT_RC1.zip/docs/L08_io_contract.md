# I/O contract
Inputs/formats/schema:
Output format/partition strategy:
Delta runtime boundary:
