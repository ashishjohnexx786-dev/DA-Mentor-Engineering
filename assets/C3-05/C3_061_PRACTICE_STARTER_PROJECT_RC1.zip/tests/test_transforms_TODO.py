# Complete during P15 after PySpark is installed.
# Use a pytest SparkSession fixture and pyspark.testing.utils.assertDataFrameEqual/assertSchemaEqual.
# Required fresh tests: valid clean row; malformed numeric rejected; duplicate product key blocks join; region totals reconcile.
