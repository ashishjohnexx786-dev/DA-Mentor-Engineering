import csv, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_source_rows_and_unique_orders():
    rows=list(csv.DictReader(open(ROOT/'data/practice/orders.csv')))
    assert len(rows)==59
    assert len({r['order_id'] for r in rows})==59

def test_exactly_one_malformed_qty():
    rows=list(csv.DictReader(open(ROOT/'data/practice/orders.csv')))
    bad=0
    for r in rows:
        try: int(r['qty'])
        except: bad+=1
    assert bad==1

def test_product_dimension_unique():
    rows=list(csv.DictReader(open(ROOT/'data/practice/products.csv')))
    assert len(rows)==8 and len({r['product_id'] for r in rows})==8

def test_reference_completed_control():
    rows=list(csv.DictReader(open(ROOT/'data/practice/orders.csv'))); total=0; n=0
    for r in rows:
        try: q=int(r['qty']); p=float(r['unit_price']); d=float(r['discount_pct'])
        except: continue
        if r['status']=='Completed': n+=1; total+=q*p*(1-d)
    assert n==50
    assert round(total,2)==17113.6
