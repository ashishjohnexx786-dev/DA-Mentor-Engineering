# Partition/shuffle evidence
Input partitions:
Exchange node:
Output partitions/files:
Reasoning:
