# Formatted plan annotation
Scan:
Filter/project:
Exchange:
Join strategy:
Aggregate/window:
AQE marker:
