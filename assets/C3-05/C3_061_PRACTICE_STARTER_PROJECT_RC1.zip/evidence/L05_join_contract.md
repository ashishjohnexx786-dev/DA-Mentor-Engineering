# Join contract
Left grain:
Right grain:
Key uniqueness proof:
Expected output grain/count:
Observed plan:
