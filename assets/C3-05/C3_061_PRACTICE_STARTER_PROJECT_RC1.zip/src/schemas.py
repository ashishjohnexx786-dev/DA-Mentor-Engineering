from pyspark.sql.types import StructType, StructField, StringType
# Deliberately read raw strings first so malformed numeric values are observable.
ORDER_RAW_SCHEMA = StructType([
    StructField('order_id', StringType(), False), StructField('order_ts', StringType(), False),
    StructField('customer_id', StringType(), False), StructField('product_id', StringType(), False),
    StructField('region', StringType(), False), StructField('status', StringType(), False),
    StructField('qty', StringType(), True), StructField('unit_price', StringType(), True),
    StructField('discount_pct', StringType(), True),
])
PRODUCT_SCHEMA = StructType([
    StructField('product_id', StringType(), False), StructField('category', StringType(), False), StructField('product_name', StringType(), False)
])
