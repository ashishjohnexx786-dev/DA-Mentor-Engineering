from pyspark.sql import SparkSession

def build_spark(app_name='c3_05_practice'):
    return (SparkSession.builder
        .appName(app_name)
        .master('local[2]')
        .config('spark.driver.memory','1g')
        .config('spark.sql.shuffle.partitions','4')
        .config('spark.sql.adaptive.enabled','true')
        .getOrCreate())
