from pyspark.sql import functions as F, Window

def validate_orders(raw_df):
    """TODO P04/P07: return (clean_df, rejected_df) using Column expressions."""
    raise NotImplementedError('Complete validate_orders during C3-05 practice')

def join_products(clean_df, products_df):
    """TODO P05: prove products key uniqueness before joining; do not hide fan-out."""
    raise NotImplementedError('Complete join_products during C3-05 practice')

def regional_metrics(joined_df):
    """TODO P06: region grain metrics."""
    raise NotImplementedError('Complete regional_metrics during C3-05 practice')

def add_customer_sequence(joined_df):
    """TODO P06: row_number over customer order time while preserving order grain."""
    raise NotImplementedError('Complete add_customer_sequence during C3-05 practice')
