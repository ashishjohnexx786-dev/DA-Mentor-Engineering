"""C3-05 practice Spark project package."""
