Status: BEGINNER-FIRST RC1 learner starter scaffold. Intentionally incomplete.

# C3-05 Distributed Processing with Spark - Practice Project

Runtime target: Apache Spark / PySpark 4.2.0, Python 3.10+, Java 17+. Use WSL2/Linux and `local[2]` on the learner laptop.

This starter is intentionally incomplete. Complete TODOs lesson-by-lesson. Do not use `collect()`/`toPandas()` on unbounded data. Save real `explain("formatted")` and Spark UI evidence only after actually running Spark.

Suggested setup:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/00_environment_check.py
pytest -q tests/test_source_controls.py
```

Then work through C3-061 P01-P16.


Runtime lane: Spark/PySpark 4.2.0; Python 3.10+; Java 17+. Save literal Spark evidence only after it actually runs.
