# Submission checklist
- Explicit schemas
- Clean + rejected evidence
- Station-key uniqueness
- Zone metrics + window
- Formatted plan + shuffle/join annotation
- Skew/quality classification for hot station
- One evidence-based performance decision
- At least 2 automated tests
- Repeatable CLI + output validation