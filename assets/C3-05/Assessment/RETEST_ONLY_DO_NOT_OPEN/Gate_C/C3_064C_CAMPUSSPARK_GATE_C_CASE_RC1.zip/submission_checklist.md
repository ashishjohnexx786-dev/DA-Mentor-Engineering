# Submission checklist
- Independent full retest
- Explicit schemas + invalid-price handling
- Hall-key proof
- Region/facility metrics + window
- Formatted plan + skew diagnosis
- One controlled tuning decision
- Tests + reproducible job