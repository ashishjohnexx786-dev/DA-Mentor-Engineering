# Submission checklist
- Independent full retest
- No prior Gate code copied
- Typed quality routing
- Join-grain proof
- Region/storage metrics + window
- Plan/skew/AQE reasoning
- Tests + CLI/handoff