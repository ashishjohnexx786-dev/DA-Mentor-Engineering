# C3-041 - Storage/File Formats/Lakehouse Practice
Status: BEGINNER-FIRST RC1 learner starter scaffold. It is intentionally incomplete.

Goal: build a small local Parquet + Delta lakehouse path, preserve source truth, apply a safe correction/upsert, prove history, and write maintenance/contract evidence.

Runtime baseline (verified 2026-09-11):
- PyArrow 25.0.1
- deltalake (delta-rs Python) 1.6.3
- Python 3.10-3.14 learner lane; this phase may use the normal Course-3 Python 3.14 environment

Start:
1. python -m venv .venv
2. source .venv/bin/activate  # WSL/Linux course route
3. python -m pip install -r requirements.txt
4. python scripts/00_runtime_check.py
5. pytest -q
6. Follow the matching C3-051 task; do not open C3-052 before saving your attempt.

Runtime honesty: this package was built in an environment without PyArrow/deltalake installed. Pure-Python reference and static tests were executed; literal Parquet/Delta runtime evidence must be produced on the learner machine.
