"""C3-04 learner TODO: create a typed Parquet dataset and validate row/schema parity."""
from pathlib import Path
# TODO: import pyarrow.csv / pyarrow.parquet or pyarrow.Table as appropriate.
SOURCE = Path("data/orders_day1.csv")
OUT = Path("outputs/parquet")

def main():
    raise NotImplementedError("Complete P03: write Parquet with intentional schema and evidence")

if __name__ == "__main__": main()
