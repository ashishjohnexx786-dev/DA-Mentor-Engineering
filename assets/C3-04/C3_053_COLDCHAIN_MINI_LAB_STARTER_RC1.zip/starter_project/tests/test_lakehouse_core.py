from pathlib import Path
from src.lakehouse_core import *
ROOT=Path(__file__).resolve().parents[1]

def rows(name): return read_csv_rows(ROOT/'data'/name)

def test_read_rows_nonempty(): assert len(rows('coldchain_day1.csv'))>0

def test_schema_detects_change():
    d=classify_schema_change(schema_columns(rows('coldchain_day1.csv')), schema_columns(rows('coldchain_day2_schema_change.csv')))
    assert len(d['added'])>=1

def test_merge_unique():
    m=merge_latest(rows('coldchain_day1.csv'), rows('coldchain_day2_schema_change.csv'), 'shipment_id')
    assert_unique(m,'shipment_id')

def test_merge_idempotent():
    m=merge_latest(rows('coldchain_day1.csv'), rows('coldchain_day2_schema_change.csv'), 'shipment_id')
    m2=merge_latest(m, rows('coldchain_day2_schema_change.csv'), 'shipment_id')
    assert m2==m

def test_partition_plan_complete():
    m=merge_latest(rows('coldchain_day1.csv'), rows('coldchain_day2_schema_change.csv'), 'shipment_id')
    p=partition_plan(m,['service_date'])
    assert sum(p.values())==len(m)

def test_file_health():
    h=file_health([100,120,130,90,1500])
    assert h['file_count']==5 and h['max']==1500

def test_diff_versions_has_change():
    a=rows('coldchain_day1.csv'); b=merge_latest(a,rows('coldchain_day2_schema_change.csv'),'shipment_id')
    d=diff_versions(a,b,'shipment_id')
    assert d['added'] or d['changed']

def test_total_is_numeric():
    m=merge_latest(rows('coldchain_day1.csv'), rows('coldchain_day2_schema_change.csv'), 'shipment_id')
    numeric_fields=[k for k in m[0] if k in ('amount','weight_kg','reading_value','fare','quantity')]
    assert numeric_fields and numeric_total(m,numeric_fields[0])>=0
