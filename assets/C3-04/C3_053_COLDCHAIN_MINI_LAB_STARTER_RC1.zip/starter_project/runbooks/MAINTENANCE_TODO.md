# Maintenance Runbook - TODO
1. Measure file/partition health.
2. Decide whether compaction is justified.
3. Reconcile current truth before/after rewrite.
4. Dry-run retention/vacuum only.
5. Check required historical recovery window.
6. Obtain approval before destructive cleanup.
7. Validate current state and required history afterward.
