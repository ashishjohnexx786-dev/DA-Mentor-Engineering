# File Health - TODO
file_count:
median_size:
mean_size:
partition_count:
skew/outliers:
compaction trigger:
parity checks:
