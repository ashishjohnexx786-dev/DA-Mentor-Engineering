# Format Decision Matrix - TODO
Workload | Access pattern | Schema | Candidate | Decision | Trade-off
