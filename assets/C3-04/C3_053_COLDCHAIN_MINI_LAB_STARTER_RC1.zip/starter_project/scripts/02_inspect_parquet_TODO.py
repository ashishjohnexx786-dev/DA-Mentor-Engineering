"""C3-04 learner TODO: inspect schema, row groups, statistics and a projected-column read."""
def main():
    raise NotImplementedError("Complete P03: inspect real Parquet metadata; do not invent output")
if __name__ == "__main__": main()
