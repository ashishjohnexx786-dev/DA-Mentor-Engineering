from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
files=list((ROOT/'scripts').glob('*.py'))+list((ROOT/'src').glob('*.py'))
for p in files:
    ast.parse(p.read_text(encoding='utf-8'))
print('syntax_files',len(files))
# Starter must remain incomplete: protected learning requires TODO scripts, not solved implementations.
expected=['01_make_parquet_TODO.py','02_inspect_parquet_TODO.py','03_delta_create_TODO.py','04_schema_evolution_TODO.py','05_merge_TODO.py','06_time_travel_TODO.py','07_maintenance_audit_TODO.py']
for n in expected:
    txt=(ROOT/'scripts'/n).read_text(encoding='utf-8')
    assert 'NotImplementedError' in txt, n
print('starter_solution_leakage','PASS')
