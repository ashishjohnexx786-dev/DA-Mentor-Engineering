"""C3-04 learner TODO: load current and prior committed versions and explain exact differences."""
def main():
    raise NotImplementedError("Complete P11: real version comparison")
if __name__ == "__main__": main()
