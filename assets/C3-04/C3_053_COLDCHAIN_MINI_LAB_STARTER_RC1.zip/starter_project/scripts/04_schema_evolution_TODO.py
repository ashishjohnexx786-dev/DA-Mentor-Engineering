"""C3-04 learner TODO: detect the supplied additive schema change and apply it deliberately."""
def main():
    raise NotImplementedError("Complete P09: deliberate schema evolution with before/after evidence")
if __name__ == "__main__": main()
