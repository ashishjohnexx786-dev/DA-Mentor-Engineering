import sys
print("Python", sys.version.split()[0])
for name in ("pyarrow","deltalake"):
    try:
        mod=__import__(name)
        print(name, getattr(mod,"__version__","unknown"))
    except Exception as e:
        print(name, "MISSING", repr(e))
        raise SystemExit(2)
