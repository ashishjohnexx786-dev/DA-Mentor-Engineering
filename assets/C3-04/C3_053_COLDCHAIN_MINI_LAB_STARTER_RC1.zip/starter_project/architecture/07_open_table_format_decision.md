# Delta vs Iceberg Decision - TODO
Workload / engines:
Catalog:
DML/upsert needs:
Schema + partition evolution:
Operational tooling:
Interoperability/migration:
Decision + assumptions:
What evidence would reverse the decision:
