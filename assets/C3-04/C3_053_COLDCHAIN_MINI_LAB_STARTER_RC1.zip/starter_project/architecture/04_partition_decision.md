# Partition Decision - TODO
Top query predicates:
Candidate keys + cardinality:
Chosen key(s):
Expected partitions/files:
Pruning benefit:
Small-file risk:
Changed-workload transfer:
