# Namespace Map - TODO
Physical locations:
- landing/raw:
- bronze:
- silver:
- gold:
Logical names:
Ownership and retention boundaries:
Anti-pattern rejected:
