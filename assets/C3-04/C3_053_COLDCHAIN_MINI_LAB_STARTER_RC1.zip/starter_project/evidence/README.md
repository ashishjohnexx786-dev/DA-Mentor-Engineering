Save real runtime output here: versions, schemas, counts, merge metrics, file-health evidence and sanitized errors. Do not save credentials or claim unexecuted output.
