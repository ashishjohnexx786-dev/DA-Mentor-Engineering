from __future__ import annotations
import csv, statistics
from pathlib import Path

def read_csv_rows(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def schema_columns(rows):
    out=[]
    for r in rows:
        for k in r:
            if k not in out: out.append(k)
    return out

def classify_schema_change(old_cols, new_cols):
    old=set(old_cols); new=set(new_cols)
    return {"added": sorted(new-old), "removed": sorted(old-new), "unchanged": sorted(old & new)}

def merge_latest(base_rows, delta_rows, key, version_fields=("updated_at","source_seq")):
    state={}
    def version(r):
        return tuple(r.get(f,"") for f in version_fields)
    for r in list(base_rows)+list(delta_rows):
        k=r[key]
        if not k:
            raise ValueError(f"blank key: {key}")
        if k not in state:
            state[k]=dict(r); continue
        a=version(state[k]); b=version(r)
        if b>a:
            merged=dict(state[k]); merged.update(r); state[k]=merged
        elif b==a and dict(r)!=state[k]:
            raise ValueError(f"ambiguous same-version rows for {k}")
    return [state[k] for k in sorted(state)]

def assert_unique(rows, key):
    vals=[r[key] for r in rows]
    if len(vals)!=len(set(vals)): raise AssertionError(f"duplicate {key}")
    return True

def numeric_total(rows, field):
    return round(sum(float(r.get(field) or 0) for r in rows), 6)

def partition_plan(rows, fields):
    out={}
    for r in rows:
        p='/'.join(f"{f}={r.get(f,'UNKNOWN')}" for f in fields)
        out[p]=out.get(p,0)+1
    return out

def file_health(sizes):
    sizes=list(sizes)
    if not sizes: return {"file_count":0,"mean":0,"median":0,"min":0,"max":0}
    return {"file_count":len(sizes),"mean":round(statistics.mean(sizes),2),"median":round(statistics.median(sizes),2),"min":min(sizes),"max":max(sizes)}

def diff_versions(old_rows, new_rows, key):
    a={r[key]:r for r in old_rows}; b={r[key]:r for r in new_rows}
    return {"added":sorted(set(b)-set(a)),"removed":sorted(set(a)-set(b)),"changed":sorted(k for k in set(a)&set(b) if a[k]!=b[k])}
