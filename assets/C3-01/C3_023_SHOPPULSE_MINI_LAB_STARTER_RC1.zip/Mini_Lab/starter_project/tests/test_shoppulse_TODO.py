# Minimum target:
# - CSV valid/naive-time quarantine
# - day2 compatible schema addition
# - duplicate return event behavior
# - safe unchanged rerun
# - checkpoint unchanged on injected failure
# - accepted+quarantine reconciliation
