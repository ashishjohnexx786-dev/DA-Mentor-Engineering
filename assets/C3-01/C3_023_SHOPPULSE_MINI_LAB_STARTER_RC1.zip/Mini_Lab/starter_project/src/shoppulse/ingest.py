"""ShopPulse learner integration boundary. Do not replace raw evidence with cleaned output."""

def run_ingestion(*args, **kwargs):
    # TODO stage 1: land source bytes + manifest
    # TODO stage 2: parse/validate and quarantine ambiguity
    # TODO stage 3: reconcile and publish replay-safe accepted state
    # TODO stage 4: commit tuple checkpoint LAST via safe replace
    raise NotImplementedError("Build ShopPulse in C3-023")
