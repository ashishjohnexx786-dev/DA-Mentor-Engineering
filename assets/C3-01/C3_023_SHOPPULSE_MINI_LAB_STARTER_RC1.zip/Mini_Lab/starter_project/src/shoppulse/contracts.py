"""Declare source contracts and compatibility rules here."""
ORDER_REQUIRED = {"order_id","updated_at","status","amount"}
ORDER_ALLOWED_ADDITIONS = {"source_system"}
