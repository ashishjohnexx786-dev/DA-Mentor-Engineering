"""Checkpoint must be committed only after durable output + reconciliation."""
def load_state(path):
    raise NotImplementedError

def commit_state_atomic(path, state):
    raise NotImplementedError
