C3-023 ShopPulse Incremental Landing starter - RC1
Build only after L01-L14 mastery. The starter intentionally does not implement the final ingestion.
Required evidence: immutable landing/manifests, accepted/quarantine, stable tuple state, replay failure/recovery, tests, reconciliation, README/runbook.
Passing is competency-only: every required competency PASS and zero critical failures.
