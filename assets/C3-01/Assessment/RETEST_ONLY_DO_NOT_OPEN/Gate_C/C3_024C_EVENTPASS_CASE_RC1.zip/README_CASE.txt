EVENTPASS GATE C - SECOND FRESH FULL RETEST ONLY
Day2 changes updated_at -> last_modified, adds channel, has one naive timestamp and one invalid numeric price.
scan_events contains a duplicate scan.
Do not open unless reviewer explicitly routes this retest.
