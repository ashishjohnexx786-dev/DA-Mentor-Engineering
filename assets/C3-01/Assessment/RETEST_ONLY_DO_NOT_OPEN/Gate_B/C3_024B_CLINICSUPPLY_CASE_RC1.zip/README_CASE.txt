CLINICSUPPLY GATE B - FRESH FULL RETEST ONLY
Day2 changes on_hand -> on_hand_qty and adds source_version.
One timestamp is naive. vendor_events contains a duplicate event.
Do not open unless reviewer explicitly routes a full retest.
