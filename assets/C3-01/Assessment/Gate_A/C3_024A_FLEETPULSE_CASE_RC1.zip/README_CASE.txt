FLEETPULSE GATE A
- Day 2 changes lat/lon names to latitude/longitude and adds source_system.
- The brief does NOT authorize silently mapping renamed fields; learner must explicitly document/approve mapping.
- V02 day2 has a timezone-naive timestamp.
- maintenance_events contains a duplicate event.
