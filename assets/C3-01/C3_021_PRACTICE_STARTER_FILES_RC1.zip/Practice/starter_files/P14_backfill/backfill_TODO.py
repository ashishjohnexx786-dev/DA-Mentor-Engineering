"""P14: explicit historical --start/--end mode; never mutate live_state.json."""
raise NotImplementedError
