"""P11: apply ordered c/u/d events to derived current state; raw events remain untouched."""
raise NotImplementedError
