"""P10: use (updated_at, order_id) as a deterministic high-watermark tuple."""
# Commit state only after durable output + reconciliation.
raise NotImplementedError
