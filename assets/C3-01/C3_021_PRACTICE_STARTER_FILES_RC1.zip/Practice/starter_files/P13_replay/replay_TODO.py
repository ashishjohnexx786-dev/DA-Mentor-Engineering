"""P13: support an injected failure after durable output but before atomic checkpoint replace."""
raise NotImplementedError
