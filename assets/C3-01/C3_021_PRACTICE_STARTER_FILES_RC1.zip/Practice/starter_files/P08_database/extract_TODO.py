"""P08: parameterized, bounded extraction."""
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "practice.db"

def extract_window(start_ts, end_ts):
    # TODO: explicit columns + bound parameters + stable ordering.
    raise NotImplementedError
