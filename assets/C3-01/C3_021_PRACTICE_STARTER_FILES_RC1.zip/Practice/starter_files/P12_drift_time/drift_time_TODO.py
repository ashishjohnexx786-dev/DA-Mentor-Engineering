"""P12: classify schema change; normalize aware timestamps; quarantine ambiguous naive timestamp."""
raise NotImplementedError
