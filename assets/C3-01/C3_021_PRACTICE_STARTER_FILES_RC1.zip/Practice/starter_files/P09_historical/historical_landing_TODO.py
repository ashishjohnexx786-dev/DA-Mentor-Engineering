"""P09: copy immutable raw batches and emit run/file manifests with hash + row count."""
raise NotImplementedError("Build from the practice brief; do not edit source files.")
