"""C3-01 P04: generate a real Parquet learning fixture after PyArrow is installed."""
from pathlib import Path
import csv
import pyarrow as pa
import pyarrow.parquet as pq

HERE = Path(__file__).resolve().parent
source = HERE / "events_source.csv"
target = HERE / "events.parquet"

rows = list(csv.DictReader(source.open(newline="", encoding="utf-8")))
table = pa.table({
    "device_id": [r["device_id"] for r in rows],
    "event_ts": [r["event_ts"] for r in rows],
    "temperature_c": [float(r["temperature_c"]) for r in rows],
    "status": [r["status"] for r in rows],
})
pq.write_table(table, target, row_group_size=3)
print(target)
print("rows", table.num_rows)
