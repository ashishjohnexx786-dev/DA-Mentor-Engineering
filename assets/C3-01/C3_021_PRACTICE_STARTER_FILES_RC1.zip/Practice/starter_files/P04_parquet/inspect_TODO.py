from pathlib import Path

# P04 learner task. Complete after make_parquet.py creates events.parquet.
def main():
    # TODO 1: import pyarrow.parquet as pq
    # TODO 2: open the real parquet file with pq.ParquetFile
    # TODO 3: print metadata row count, row groups and schema
    # TODO 4: read only device_id and event_ts and reconcile row counts
    raise NotImplementedError('Complete P04 after the lesson walkthrough')

if __name__ == '__main__':
    main()
