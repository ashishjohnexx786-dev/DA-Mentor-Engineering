LOCAL COURSE API
Token is intentionally fake: C3_FAKE_TOKEN_2026.
Use it only as a learning credential and do not hard-code it in learner solution code.
Start:
python mock_api.py
Base URL: http://127.0.0.1:18765
