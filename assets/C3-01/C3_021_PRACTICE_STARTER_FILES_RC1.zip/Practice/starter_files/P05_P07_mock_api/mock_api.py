"""C3-01 local HTTP fixture using Python standard library only."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json

HOST, PORT = "127.0.0.1", 18765
TOKEN = "C3_FAKE_TOKEN_2026"
COUNTERS = {"rate": 0, "transient": 0}
ORDERS = [
    {"order_id":"A001","updated_at":"2026-08-20T10:00:00Z","amount":120},
    {"order_id":"A002","updated_at":"2026-08-20T10:05:00Z","amount":80},
    {"order_id":"A003","updated_at":"2026-08-20T10:10:00Z","amount":210},
    {"order_id":"A004","updated_at":"2026-08-20T10:15:00Z","amount":55},
    {"order_id":"A005","updated_at":"2026-08-20T10:20:00Z","amount":175},
]

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("MOCK_API", fmt % args)

    def send_json(self, status, body, headers=None):
        raw=json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(raw)

    def authorized(self):
        return self.headers.get("Authorization") == f"Bearer {TOKEN}"

    def do_GET(self):
        u=urlparse(self.path)
        if u.path == "/health":
            return self.send_json(200,{"status":"ok","service":"c3-01-mock"})
        if not self.authorized():
            return self.send_json(401,{"error":"unauthorized"})
        if u.path == "/profile":
            return self.send_json(200,{"account_id":"TRAINING","scope":["orders:read"]})
        if u.path == "/orders":
            page=int(parse_qs(u.query).get("page",["1"])[0])
            size=2
            start=(page-1)*size
            rows=ORDERS[start:start+size]
            next_page=page+1 if start+size < len(ORDERS) else None
            return self.send_json(200,{"page":page,"next_page":next_page,"total":len(ORDERS),"orders":rows})
        if u.path == "/rate-limit-once":
            COUNTERS["rate"] += 1
            if COUNTERS["rate"] == 1:
                return self.send_json(429,{"error":"rate_limited"},{"Retry-After":"1"})
            return self.send_json(200,{"status":"ok","attempt":COUNTERS["rate"]})
        if u.path == "/transient":
            COUNTERS["transient"] += 1
            if COUNTERS["transient"] <= 2:
                return self.send_json(503,{"error":"temporary","attempt":COUNTERS["transient"]})
            return self.send_json(200,{"status":"ok","attempt":COUNTERS["transient"]})
        return self.send_json(404,{"error":"not_found"})

if __name__ == "__main__":
    print(f"C3-01 mock API on http://{HOST}:{PORT}")
    HTTPServer((HOST,PORT),Handler).serve_forever()
