import os

BASE='http://127.0.0.1:18765'
TOKEN_ENV='C3_FAKE_TOKEN_2026'

def main():
    # TODO P05: request /health with timeout and validate response contract.
    # TODO P05: call /profile using token from environment; never log the token.
    # TODO P06: follow /orders pagination to termination and prove unique/full count.
    # TODO P06: handle 429 /rate-limit-once using Retry-After with a bound.
    # TODO P07: retry only declared transient failures with capped backoff+jitter.
    raise NotImplementedError('Complete P05-P07 after each lesson walkthrough')

if __name__=='__main__':
    main()
