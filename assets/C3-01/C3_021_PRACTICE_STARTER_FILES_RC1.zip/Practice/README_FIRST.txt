C3-01 PRACTICE ENVIRONMENT
These are starter files and synthetic learning data, not solutions.

P02 customers_messy.csv
P03 orders_nested.json
P04 PyArrow Parquet generator/inspection
P05-P07 local mock API
P08 SQLite bounded extraction
P09 historical landing
P10 high-watermark incremental load
P11 CDC event semantics
P12 schema/time drift
P13 checkpoint/replay
P14 reconciliation/backfill

Attempt the matching C3-021 task before opening C3-022.
Never use real credentials or private employer data.
