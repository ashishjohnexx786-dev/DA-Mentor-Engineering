C3-01 PRACTICE STARTER FILES - BEGINNER-FIRST RC1

1. Keep original source files unchanged. Work in your own work/Pxx folder.
2. Follow the matching lesson walkthrough before independent Pxx.
3. Freeze evidence/Pxx/attempt_001 before opening C3-022 review.
4. Review does not count as mastery. Close it and solve a changed retry.
5. PyArrow is first installed at L04 if missing. Requests first checked at L05.
6. Do not install Kafka/Debezium/Airflow/Spark here.
7. Never put a real token in source, logs, screenshots or evidence.
