# C3-03 reliable orchestration practice project
Pure Python code is intentionally runnable without Airflow so business-side-effect correctness can be tested independently.
The Airflow DAG is an incomplete learner artifact. Do not replace the TODOs with copied review answers.

Core loop: logical interval -> wait -> extract -> validate -> merge -> reconcile -> atomic publish.
Airflow learner runtime baseline: Apache Airflow 3.3.1 in WSL2.
