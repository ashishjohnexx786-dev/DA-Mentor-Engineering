"""C3-03 learner DAG. Keep TODOs as genuine practice; pure business logic lives in src/."""
from datetime import datetime, timedelta, timezone
from airflow.sdk import dag, task, get_current_context
from airflow.providers.standard.sensors.filesystem import FileSensor

DAG_ID = 'c3_03_reliable_orders'

@dag(
    dag_id=DAG_ID,
    schedule='@daily',
    start_date=datetime(2026, 9, 1, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    params={'min_rows': 1, 'simulate_transient_failure': False},
    tags=['course3','c3-03','practice'],
)
def reliable_orders():
    @task
    def resolve_partition():
        context = get_current_context()
        # TODO P04: derive a stable YYYY-MM-DD partition from Airflow logical/data-interval context.
        raise NotImplementedError('P04 interval mapping')

    partition = resolve_partition()

    wait_for_input = FileSensor(
        task_id='wait_for_input',
        fs_conn_id='c3_03_incoming',
        # TODO P08: make this interval-specific using the resolved/logical partition.
        filepath='TODO.csv',
        timeout=120,
        poke_interval=10,
        deferrable=True,
    )

    @task(retries=2, retry_delay=timedelta(seconds=5), execution_timeout=timedelta(minutes=5))
    def transient_guard(partition_date: str):
        # TODO P06: call the packaged fail_once guard only when the run Param requests the simulation.
        return partition_date

    @task
    def extract(partition_date: str):
        # TODO P03/P04: call thin pure logic and return only compact metadata/path, not the dataset.
        raise NotImplementedError('P03 thin task wrapper')

    @task
    def validate(extract_meta: dict):
        # TODO: enforce min_rows and return compact validation metadata.
        raise NotImplementedError('validation task')

    @task(pool='warehouse_small')
    def load(validated: dict):
        # TODO P09: call stale-safe/idempotent merge logic.
        raise NotImplementedError('idempotent load')

    @task(pool='warehouse_small')
    def reconcile(load_meta: dict):
        # TODO: independently verify target grain/count/version/amount controls.
        raise NotImplementedError('reconciliation')

    @task
    def publish(recon: dict):
        # TODO P09: atomic interval-partitioned publish. No blind append.
        raise NotImplementedError('atomic publish')

    guard = transient_guard(partition)
    extracted = extract(guard)
    validated = validate(extracted)
    loaded = load(validated)
    checked = reconcile(loaded)
    published = publish(checked)
    wait_for_input >> guard
    return published

reliable_orders()
