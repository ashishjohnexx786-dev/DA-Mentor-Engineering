from pathlib import Path
import sys, json
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from pipeline_core import read_orders, run_partition, snapshot, fail_once

def copy_project(tmp_path):
    import shutil
    p=tmp_path/'p'; shutil.copytree(ROOT/'data',p/'data'); return p

def test_valid_source_reads():
    rows=read_orders(ROOT/'data'/'incoming'/'orders_2026-09-01.csv')
    assert len(rows)==3 and rows[0]['net_sales'] > 0

def test_chronological_merge_and_newer_version(tmp_path):
    p=copy_project(tmp_path)
    run_partition(p,'2026-09-01'); run_partition(p,'2026-09-02'); run_partition(p,'2026-09-03')
    s=snapshot(p/'state'/'warehouse.sqlite')
    assert s['row_count']==7
    o7002=[r for r in s['rows'] if r[0]=='O7002'][0]
    assert o7002[2]==2 and o7002[4].startswith('2026-09-02')

def test_old_partition_replay_is_stale_safe(tmp_path):
    p=copy_project(tmp_path)
    run_partition(p,'2026-09-01'); run_partition(p,'2026-09-02')
    before=snapshot(p/'state'/'warehouse.sqlite')
    run_partition(p,'2026-09-01')
    after=snapshot(p/'state'/'warehouse.sqlite')
    assert before==after

def test_same_partition_rerun_is_idempotent(tmp_path):
    p=copy_project(tmp_path)
    a=run_partition(p,'2026-09-01'); b=run_partition(p,'2026-09-01')
    assert a['warehouse_row_count']==b['warehouse_row_count']==3
    assert snapshot(p/'state'/'warehouse.sqlite')['row_count']==3

def test_fail_once_then_succeeds(tmp_path):
    with pytest.raises(RuntimeError): fail_once(tmp_path,'x')
    assert fail_once(tmp_path,'x')=='retry-safe success'

def test_malformed_timestamp_fails_permanently():
    with pytest.raises(ValueError): read_orders(ROOT/'data'/'incoming'/'orders_MALFORMED.csv')
