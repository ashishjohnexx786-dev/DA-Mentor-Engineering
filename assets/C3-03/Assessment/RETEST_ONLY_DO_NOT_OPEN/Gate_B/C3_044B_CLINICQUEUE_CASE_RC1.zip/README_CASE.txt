Fresh protected orchestration case: ClinicQueue. Build from these source partitions. Do not modify source files. Save run/task/interval and reconciliation evidence.
