Fresh protected orchestration case: CampusMeals. Build from these source partitions. Do not modify source files. Save run/task/interval and reconciliation evidence.
