# Recovery runbook - complete after genuine practice
## Normal signal / expected schedule
## Detection signals
## First diagnostics (run/task/interval/state/log)
## Missing/late input
## Transient dependency failure
## Permanent bad data
## Partial publish/load failure
## Historical reprocessing/backfill
## Pool/resource saturation
## Rollback / deploy regression
## Post-recovery reconciliation
## Ownership/escalation
