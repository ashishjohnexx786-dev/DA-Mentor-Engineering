# C3-043 RapidRoute Mini-Lab starter
Fresh orchestration scenario. The pure pipeline is runnable; build/complete a fresh DAG and evidence packet independently.
Do not reuse the C3-041 DAG by simple renaming: interval paths, readiness rules, quality floor and recovery requirements differ in the Mini-Lab brief.
