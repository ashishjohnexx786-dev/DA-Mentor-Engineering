from pathlib import Path
import ast, re, sys
root=Path(__file__).resolve().parents[1]
dag=root/'dags'/'c3_043_rapidroute_TODO.py'
text=dag.read_text(encoding='utf-8')
tree=ast.parse(text)
checks={
  'uses_airflow_sdk':'from airflow.sdk import' in text,
  'uses_standard_filesensor':'airflow.providers.standard.sensors.filesystem' in text,
  'deferrable_wait':'deferrable=True' in text.replace(' ',''),
  'warehouse_pool':"pool='warehouse_small'" in text or 'pool="warehouse_small"' in text,
  'timezone_aware_start':'timezone.utc' in text,
  'no_datetime_now':'datetime.now(' not in text and 'date.today(' not in text,
  'no_obvious_secrets':not re.search(r'(AKIA[0-9A-Z]{16}|BEGIN (RSA|OPENSSH) PRIVATE KEY|password\s*=\s*[\"\'][^\"\']+)',text,re.I),
}
bad=[k for k,v in checks.items() if not v]
print(checks)
if bad: print('FAIL',bad); sys.exit(1)
print('PASS static Airflow scaffold audit')
