Fill before review:
- Per-run Params:
- Environment/Variable owned configuration:
- Connection IDs:
- Secrets (location/mechanism, never literal value):
- Code constants:
- Configuration precedence / owner:
- Repository secret-scan evidence:
