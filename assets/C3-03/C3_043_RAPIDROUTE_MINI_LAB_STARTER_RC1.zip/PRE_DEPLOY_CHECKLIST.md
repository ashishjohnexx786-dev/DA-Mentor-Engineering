[ ] python -m py_compile src/pipeline_core.py src/run_core.py dags/c3_03_reliable_orders_TODO.py
[ ] pytest -q
[ ] python scripts/static_airflow_audit.py
[ ] airflow dags list / import-error check on learner Airflow runtime
[ ] inspect graph/dependencies
[ ] focused airflow dags test / task test evidence on learner runtime
[ ] no secrets / generated runtime state committed
[ ] runbook updated for changed failure/recovery behavior
