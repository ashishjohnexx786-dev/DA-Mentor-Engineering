Complete before C3-03 mastery:
- source/version identity
- prerequisites + dependency pin policy
- connections/variables/params/pools required (no secret values)
- deploy steps
- DAG discovery + schedule verification
- rollback condition and action
- historical reprocess/backfill decision
- validation controls after deploy/recovery
- owner/escalation boundary
