Save sanitized command output, run/task/interval notes and reconciliation here. Do not save credentials.
