For each incident record:
- dag_id / run_id / task_id:
- logical interval:
- observed state/symptom:
- first decisive log/metadata evidence:
- failure layer: parse | schedule/dependency | waiting | task runtime | data quality | publish/state
- side effects already committed?:
- smallest safe recovery action:
- post-recovery validation/reconciliation:
- what must NOT be rerun blindly:
