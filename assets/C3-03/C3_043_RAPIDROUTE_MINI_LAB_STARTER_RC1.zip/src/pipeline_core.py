from __future__ import annotations
import csv, json, os, sqlite3
from datetime import datetime
from decimal import Decimal
from pathlib import Path

REQUIRED = {'order_id','customer_id','qty','unit_price','updated_at'}

def parse_ts(value:str)->datetime:
    return datetime.fromisoformat(value.replace('Z','+00:00'))

def read_orders(path: str | Path):
    path=Path(path)
    with path.open(newline='',encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    if not rows: raise ValueError('empty input')
    if set(rows[0]) != REQUIRED: raise ValueError(f'schema mismatch: {set(rows[0])}')
    out=[]
    for r in rows:
        qty=int(r['qty']); price=Decimal(r['unit_price']); ts=parse_ts(r['updated_at'])
        if qty <= 0 or price < 0: raise ValueError('invalid quantity/price')
        out.append({**r,'qty':qty,'unit_price':price,'updated_at_dt':ts,'net_sales':Decimal(qty)*price})
    return out

def ensure_db(db_path: str | Path):
    db_path=Path(db_path); db_path.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(db_path)
    con.execute("CREATE TABLE IF NOT EXISTS orders_current(order_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, qty INTEGER NOT NULL, unit_price TEXT NOT NULL, updated_at TEXT NOT NULL, net_sales TEXT NOT NULL)")
    con.commit(); return con

def merge_orders(db_path, rows):
    con=ensure_db(db_path); stats={'inserted':0,'updated':0,'stale_or_same':0}
    try:
        for r in rows:
            old=con.execute('SELECT updated_at FROM orders_current WHERE order_id=?',(r['order_id'],)).fetchone()
            if old is None:
                con.execute('INSERT INTO orders_current VALUES(?,?,?,?,?,?)',(r['order_id'],r['customer_id'],r['qty'],str(r['unit_price']),r['updated_at'],str(r['net_sales']))); stats['inserted']+=1
            elif parse_ts(r['updated_at']) > parse_ts(old[0]):
                con.execute('UPDATE orders_current SET customer_id=?,qty=?,unit_price=?,updated_at=?,net_sales=? WHERE order_id=?',(r['customer_id'],r['qty'],str(r['unit_price']),r['updated_at'],str(r['net_sales']),r['order_id'])); stats['updated']+=1
            else: stats['stale_or_same']+=1
        con.commit(); return stats
    finally: con.close()

def snapshot(db_path):
    con=ensure_db(db_path)
    try:
        rows=con.execute('SELECT order_id,customer_id,qty,unit_price,updated_at,net_sales FROM orders_current ORDER BY order_id').fetchall()
    finally: con.close()
    total=sum(Decimal(r[5]) for r in rows)
    return {'row_count':len(rows),'net_sales':str(total.quantize(Decimal('0.01'))),'rows':rows}

def atomic_publish(out_path, payload):
    out_path=Path(out_path); out_path.parent.mkdir(parents=True,exist_ok=True)
    tmp=out_path.with_suffix(out_path.suffix+'.tmp')
    tmp.write_text(json.dumps(payload,indent=2,default=str),encoding='utf-8')
    os.replace(tmp,out_path)

def fail_once(marker_dir, key):
    marker=Path(marker_dir)/f'{key}.marker'; marker.parent.mkdir(parents=True,exist_ok=True)
    if not marker.exists():
        marker.write_text('first attempt recorded',encoding='utf-8')
        raise RuntimeError('simulated transient failure: first attempt')
    return 'retry-safe success'

def run_partition(project_root, partition_date, prefix='orders', min_rows=1):
    root=Path(project_root); src=root/'data'/'incoming'/f'{prefix}_{partition_date}.csv'
    rows=read_orders(src)
    if len(rows) < min_rows: raise ValueError(f'quality floor failed: {len(rows)} < {min_rows}')
    db=root/'state'/'warehouse.sqlite'
    merge=merge_orders(db,rows); snap=snapshot(db)
    payload={'partition_date':partition_date,'source_rows':len(rows),'merge':merge,'warehouse_row_count':snap['row_count'],'warehouse_net_sales':snap['net_sales']}
    atomic_publish(root/'outputs'/f'dt={partition_date}'/'summary.json',payload)
    return payload
