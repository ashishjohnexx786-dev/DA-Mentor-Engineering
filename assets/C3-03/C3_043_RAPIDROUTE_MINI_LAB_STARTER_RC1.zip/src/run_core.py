from pathlib import Path
import argparse, json
from pipeline_core import run_partition
if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('date'); p.add_argument('--root',default=str(Path(__file__).resolve().parents[1])); p.add_argument('--prefix',default='shipments')
    args=p.parse_args(); print(json.dumps(run_partition(args.root,args.date,args.prefix),indent=2))
