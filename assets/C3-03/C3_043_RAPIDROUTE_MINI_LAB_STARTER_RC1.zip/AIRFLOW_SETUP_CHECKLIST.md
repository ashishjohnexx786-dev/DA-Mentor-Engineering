1. Work inside WSL2 under the Linux filesystem.
2. Create/activate a fresh venv.
3. Install apache-airflow==3.3.1 using the matching official constraints URL for your Python minor version.
4. Verify `airflow version`.
5. Use `airflow standalone` only for the local learning environment.
6. Create a filesystem Connection ID `c3_03_incoming` pointing to this project's data/incoming directory.
7. Create pool `warehouse_small` with a small slot count (for example 1-2 in the laptop lab).
8. Do not commit generated Airflow metadata/logs/admin credentials.
9. Verify `airflow dags list` and inspect import errors before triggering runs.
