# DAG design worksheet
Expected flow (redesign/defend; do not treat as final answer):
resolve interval -> wait readiness -> extract -> validate -> merge/load -> reconcile -> publish

For every task record input, output/reference, side effect, retry policy, idempotence mechanism and downstream blocker.
